# Análise de Conformidade com Normas do Ministério da Defesa (MD)

**Data:** 26/12/2025
**Projeto:** DoseToRisk (Programa_Python_AR)
**Escopo:** Avaliação de aderência às publicações de Doutrina Militar do Estado-Maior Conjunto das Forças Armadas (EMCFA).

---

## 1. Contextualização
O sistema **DoseToRisk** opera como um motor de cálculo de risco radiológico (câncer/estocástico) baseado nos modelos BEIR V e VII, processando saídas do código de dispersão HotSpot. No contexto de defesa, ele se enquadra como uma **Ferramenta de Apoio à Decisão (FAD)** para Defesa QBRN (Química, Biológica, Radiológica e Nuclear) e Apoio de Saúde.

## 2. Normas Aplicáveis Identificadas

Após revisão da lista de publicações doutrinárias do EMCFA, identificamos as seguintes normas como **diretamente aplicáveis** ou **correlatas**:

### A. Normas de Saúde e Apoio Logístico (Principal Aderência)
*   **MD42-M-04: Manual de Apoio de Saúde em Operações Conjuntas (2ª Ed. 2023)**
    *   **Relevância:** Alta.
    *   **Justificativa:** O sistema estima riscos à saúde (câncer) de tropas ou populações expostas. O manual MD42-M-04 estabelece como o apoio de saúde deve planejar a triagem, evacuação e tratamento. Embora o foco do software seja risco tardio (estocástico), ele compõe o quadro de *Health Surveillance* (Vigilância em Saúde) pós-evento.
    *   **Ponto de Atenção:** A doutrina militar prioriza **efeitos agudos** (Casualty Estimation para eficácia de combate) no curto prazo. O software foca em **efeitos tardios**. É crucial explicitar que a ferramenta visa o planejamento de longo prazo e gestão de consequências, não necessariamente a triagem tática imediata (salvo se ajustado para doses agudas).

### B. Normas de Qualidade e Ciclo de Vida
*   **MD40-M-03: Boas Práticas para a Garantia da Qualidade Integrada ao Ciclo de Vida de Sistemas de Defesa (1ª Ed. 2023)**
*   **MD40-G-01: Glossário das Forças Armadas**
    *   **Relevância:** Média/Alta.
    *   **Justificativa:** O código atual já implementa rigorosos mecanismos de auditoria (`audit_header`, *hashes* SHA-256 de insumos, logs JSON granulares). Isso demonstra alinhamento nativo com os princípios de rastreabilidade e integridade de dados exigidos para softwares de defesa críticos.

### C. Doutrina de Operações e Defesa
*   **MD30-M-01: Doutrina de Operações Conjuntas**
*   **MD51-M-04: Doutrina Militar de Defesa**
    *   **Relevância:** Estratégica.
    *   **Justificativa:** O uso de ferramentas de simulação para QBRN suporta o Planejamento Baseado em Capacidades e a avaliação de cenários de risco, fundamentais na doutrina de emprego conjunto.

---

## 3. Avaliação do Estado Atual (Gap Analysis)

| Requisito / Área | Status Atual | Observação |
| :--- | :--- | :--- |
| **Estimativa de Risco (Saúde)** | ✅ Atendido (Parcial) | O sistema calcula risco de câncer (BEIR VII/V). **GAP:** Não calcula explicitamente *Acute Radiation Syndrome* (Síndrome Aguda) ou *Performance Degradation* (Degradação de Desempenho) conforme padrões NATO AMedP-8(C), que são o foco tático primário. |
| **Auditoria e Rastreabilidade** | ✅ Atendido (Excelente) | Logs detalhados, hash de arquivos e versionamento de execução atendem e superam requisitos básicos do MD40. |
| **Integração Doutrinária** | ⚠️ Parcial | A terminologia usada no código (ex: "HotSpot", "TEDE") é técnica internacional, mas não necessariamente alinhada com os termos padronizados no **MD35-G-01 Glossário das FA**. |
| **Segurança da Informação** | ✅ Atendido | O uso de hashes para garantir integridade dos inputs é um ponto forte de conformidade com políticas de segurança (MD31). |

---

## 4. Recomendações Estratégicas

1.  **Posicionamento do Produto:** Definir claramente o software como uma ferramenta de **"Vigilância em Saúde e Apoio à Decisão para Gestão de Consequências Pós-Evento QBRN"**. Isso evita a confusão com ferramentas de estimativa de baixas táticas imediatas.
2.  **Expansão para Efeitos Agudos (Futuro):** Para maior aderência ao **MD42-M-04**, recomenda-se futuramente implementar módulos que calculem a probabilidade de efeitos determinísticos (vômitos, incapacitação), usando limites de dose (ex: > 0.7 Gy).
3.  **Padronização Terminológica:** Revisar os relatórios de saída para garantir que termos como "Zona de Exclusão" ou "Nível de Risco" estejam semânticamente alinhados com a doutrina brasileira.
