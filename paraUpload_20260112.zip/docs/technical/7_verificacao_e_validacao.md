# Verificação e Validação (V&V)

Como software de aplicação científica crítica, o Dose2Risk implementa rotinas estritas de verificação de integridade e permite validação matemática detalhada.

---

## 1. Verificação de Integridade e Instalação

Antes da execução ou implantação, recomenda-se verificar a integridade dos arquivos de configuração e a correta importação dos módulos de cálculo.

### Script de Verificação (`check_risk_setup.py`)
Um script de diagnóstico pode ser executado para validar:
1.  Se o arquivo JSON `config/beir_hotspot_parameters.json` existe e é sintaticamente válido.
2.  Se a classe `CalculadoraRisco` consegue carregar estes parâmetros sem erros.
3.  Se não há conflitos de dependência no ambiente Python.

**Execução:**
```bash
python check_risk_setup.py
```
*Saída Esperada:* Status "VERIFICAÇÃO CONCLUÍDA: O sistema parece íntegro."

---

## 2. Validação Matemática ("Caixa Branca")

A validação dos resultados calculados pelo Dose2Risk pode ser auditada manualmente, célula a célula, utilizando o **Log de Execução Auditorável**.

### Procedimento de Auditoria
O sistema gera um arquivo `.log` (ex: `4_execution_log_...log`) junto aos resultados. Este arquivo contém entradas JSON para cada cálculo individual.

**Passo a Passo para Validação Manual:**
1.  Abra o arquivo de Log.
2.  Localize uma entrada de interesse (ex: `Context: male|lung|A_1.0`).
3.  Observe os campos:
    *   `Dose_Sv`: A dose de entrada.
    *   `Model`: O modelo selecionado (`BEIR_VII` ou `BEIR_V`).
    *   `Equation`: A fórmula exata aplicada.
    *   `Params`: Os valores numéricos dos coeficientes ($\beta, \gamma, \eta$, etc.) usados naquele momento.
4.  Substitua os valores na equação e calcule manualmente.
5.  Compare com o campo `Result_ERR`.

### Exemplo de Entrada de Log
```json
{
    "Row_ID": 15,
    "Context": "female|thyroid|A_0.5",
    "Model": "BEIR_V",
    "Dose_Sv": "1.2000e-01",
    "Result_ERR": "9.0000e-01",
    "Equation": "ERR = 7.5 * dose_Sv",
    "Params": { "threshold": 18, "coef_young": 7.5 }
}
```
*Validação:* $1.2 \times 10^{-1} \times 7.5 = 0.9$. O resultado confere.

---

---

## 3. Verificação Visual (Gráficos e UI)

A partir da v2.1, a integridade da visualização deve ser checada.

### Verificação Automatizada (`verify_charts.py`)
Script dedicado para testar o módulo `RiskChartGenerator` isoladamente.
*   **Entrada:** Arquivo CSV `3_calculated_risks` validado.
*   **Processo:** Gera um conjunto de teste de gráficos em pasta temporária (`tests/temp_charts`).
*   **Critério de Sucesso:** Geração de arquivos PNG não vazios correspondentes aos órgãos do CSV.

### Verificação na Interface
1.  **Acesso:** Botão "Visualizar Gráficos" na tela de resultados.
2.  **Validação:**
    *   Verificar se o modal de galeria abre corretamente (overlay escuro).
    *   Confirmar se a imagem principal corresponde à miniatura selecionada.
    *   Testar navegação via setas (tela e teclado) e clique nas miniaturas.
    *   Garantir que os valores plotados (eixo Y logarítmico) sejam coerentes com o CSV de risco.

---

## 4. Histórico de Verificações

*   **2025-12-11:** Auditoria inicial de código. Identificou-se uso genérico de modelo de Leucemia para altas doses.
*   **2025-12-17:** Lançamento da v2.0.
    *   Correção dos modelos de alta dose (Implementação Híbrida).
    *   Migração para Arquitetura Data-Driven (JSON).
    *   Validação de integridade realizada com sucesso.
*   **2026-01-06:** Implementação da v2.1.
    *   Filtros Avançados de Interface (Sexo, Órgão, Modelo).
    *   Trava de Segurança (4Sv) com supressão opcional.
    *   Filtros Avançados de Interface (Sexo, Órgão, Modelo).
    *   Trava de Segurança (4Sv) com supressão opcional.
    *   Internacionalização (i18n) e Suporte a Temas (Dark/Light).
*   **2026-01-12:** Implementação de Visualização (v2.2?).
    *   Módulo `vis.charts` (Matplotlib).
    *   Integração no Pipeline de Cálculo.
    *   Interface de Galeria (Modal/Lightbox) na Web.
    *   Inclusão de gráficos no pacote de download (.zip).
