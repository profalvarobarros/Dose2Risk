# Guia de Coleta de Informações para Uso do Sistema

Para utilizar o Dose2Risk com rigor científico, o pesquisador/usuário deve reunir informações específicas antes da execução. Este guia orienta onde obter cada dado.

---

## 1. Dados Dosimétricos (Obrigatório)

*   **Dado Necessário:** Arquivos `.txt` de saída do HotSpot.
*   **Onde Obter:** Software *HotSpot Health Physics Codes* (Lawrence Livermore National Laboratory).
*   **Procedimento:**
    1.  Realize a simulação de dispersão no HotSpot ("General Plume").
    2.  Vá em `Output` > `Text Output`.
    3.  Salve o arquivo como `.txt` (ex: `Output_Cenario_1.txt`).
    4.  **Atenção:** Garanta que a opção de incluir todos os órgãos ("Organ Dose") esteja marcada na simulação do HotSpot se desejar análise completa.

## 2. Dados do Indivíduo (Obrigatório)

Estas informações definem os coeficientes epidemiológicos que serão selecionados.

*   **Idade na Exposição (`exp_age`):** A idade (em anos) que o indivíduo tinha no momento do acidente nuclear/radiológico.
*   **Idade Atingida/Atual (`att_age`):** A idade atual do indivíduo (momento da avaliação de risco).
    *   *Regra:* `att_age` deve ser maior ou igual a `exp_age`.
*   **Sexo:** O sistema calcula automaticamente para ambos os sexos (M/F) e gera linhas separadas nos arquivos de saída ou colunas identificadas. O pesquisador deve olhar para a linha/coluna correspondente ao sexo do seu sujeito de estudo.

## 3. Dados Demográficos de Incidência (Opcional, mas Recomendado)

Para calcular o **LAR (Risco Absoluto)**, o sistema precisa saber a incidência natural de câncer na população à qual o indivíduo pertence.

*   **Dado Necessário:** Incidência Basal Vitalícia (`baseline_incidence`) por tipo de câncer.
*   **Onde Obter:**
    *   **Brasil:** Instituto Nacional de Câncer (**INCA**). Procure por "Estimativa de Incidência de Câncer no Brasil". Use as "Taxas Ajustadas" e projete para a expectativa de vida.
    *   **EUA:** Tabelas SEER (*Surveillance, Epidemiology, and End Results Program*) ou tabelas originais do relatório BEIR VII.
    *   **Mundo:** GLOBOCAN (IARC/WHO).
*   **Como Inserir no Sistema:**
    1.  Abra o arquivo `dados_referencia/beirVII_hotspot_organ_equivalance_parameters.csv`.
    2.  Edite as colunas `baseline_incidence_M` e `baseline_incidence_F`.
    3.  Insira a probabilidade em decimal (ex: 3% = `0.03`).
    *   *Fórmula de Conversão Rápida:*
        $$ P \approx \frac{\text{Taxa Anual por 100k}}{100.000} \times \text{Expectativa de Vida (Anos)} $$

## 4. Parâmetros do Modelo BEIR (Avançado)

Caso deseje alterar a metodologia (ex: usar coeficientes de um novo estudo publicado em 2026):

*   **Onde Obter:** Relatórios científicos da *National Academy of Sciences* (BEIR series), publicações da UNSCEAR ou ICRP.
*   **Como Atualizar:** Edite as colunas `beta`, `gamma`, `eta` no arquivo CSV de parâmetros.
    *   *Cuidado:* Alterar esses números muda a "física" do cálculo. Faça apenas com embasamento bibliográfico.
