# Fluxo Macro do Sistema Dose2Risk

## Visão Geral
O pipeline computacional Dose2Risk opera como uma cadeia sequencial de processamento de dados (ETL - Extract, Transform, Load/Calculate), projetada para garantir integridade, rastreabilidade e validade científica na conversão de dosimetria em risco radiológico.

---

## Diagrama Funcional
```mermaid
graph TD
    A[Arquivos HotSpot (.txt)] -->|Extração de Texto| B(Extrator: Parse Estruturado)
    B -->|Normalização| C[CSV Tabular Intermediário]
    C -->|Transposição| D(Transpositor: Pivotagem de Dados)
    D -->|Matriz Órgão x Cenário| E[CSV Transposto]
    E -->|Motor de Cálculo| F{Calculadora de Risco}
    G[Parâmetros BEIR & INCA (.csv)] --> F
    F -->|Decisão Metodológica (100 mSv)| H{Switch de Modelo}
    H -->|< 100 mSv| I[Modelo BEIR VII]
    H -->|>= 100 mSv| J[Modelo BEIR V]
    I --> K[Cálculo de ERR]
    J --> K
    K -->|Aplicação Baseline INCA| L[Cálculo de LAR]
    K --> M[Saída: Arquivo _ERR.csv]
    L --> N[Saída: Arquivo _LAR.csv]
    N -->|Geração de Gráficos| O(Gerador de Visualização)
    O --> P[Saída: Gráficos PNG (.png)]
    M --> O
    N --> O

## Etapas Detalhadas

### 1. Entrada de Dados (Input Layer)
*   **Fonte:** Arquivos de saída "General Plume" do software HotSpot 3.1.2.
*   **Conteúdo:** Dados de descargas atmosféricas, incluindo variáveis meteorológicas (classe de estabilidade, velocidade do vento) e dosimétricas (CDE - Committed Dose Equivalent por órgão e distância).
*   **Validação:** O sistema verifica a integridade do cabeçalho e a presença de palavras-chave ("HotSpot", "Wind Speed") antes de aceitar o arquivo.

### 2. Estágio de Extração (Extraction Layer)
*   **Processo:** O módulo `ExtratorHotspot` utiliza Expressões Regulares (Regex) para varrer os arquivos de texto não estruturados.
*   **Normalização:** Converte unidades, trata notação científica (ex: '1,2E+02' -> 120.0) e unifica nomes de órgãos para um padrão interno (snake_case).
*   **Produto:** Um DataFrame "Longo" contendo todas as variáveis brutas.

### 3. Estágio de Transposição (Transformation Layer)
*   **Processo:** O módulo `TranspositorHotspot` reorienta os dados.
*   **Lógica:** Converte a lista vertical de doses em uma matriz onde:
    *   **Linhas:** Órgãos alvo (Tireoide, Pulmão, etc.).
    *   **Colunas:** Cenários (Combinação de Classe de Estabilidade de Pasquill + Distância do ponto de release).
*   **Objetivo:** Preparar a estrutura de dados para o cálculo matricial de risco.

### 4. Motor de Cálculo (Calculation Layer)
*   **Inputs:**
    *   Matriz de Doses (do estágio anterior).
    *   Parâmetros Epidemiológicos (Arquivo CSV de configuração).
    *   **Filtros de Seleção (Interface Web):**
        *   Filtro de Sexo (Masculino/Feminino).
        *   Filtro de Modelos (ERR/LAR).
        *   Filtro de Órgãos (Seleção granular).
        *   Trava de Segurança (> 4 Sv).
    *   Inputs do Usuário: Idade na Exposição, Idade Atual, Sexo (implícito na análise de colunas de incidência).
*   **Lógica de Decisão:** Para cada célula da matriz (Órgão, Cenário), o sistema verifica a dose absorvida ($D$).
    *   Se $D < 0.1$ Sv: Aplica equações do BEIR VII (LNT).
    *   Se $D \ge 0.1$ Sv: Aplica equações do BEIR V (Linear-Quadrático/Outros).

*   **(Novo na v2.1) Interface de Resultados:**
    *   **Galeria Interativa:** Visualização em modal (Lightbox) dos gráficos gerados.
    *   **Navegação:** Thumbnails e controles de slide para análise rápida.

### 6. Estágio de Visualização (Visualization Layer)
*   **Processo:** O módulo `RiskChartGenerator` consome o DataFrame final de riscos.
*   **Lógica:**
    *   Para cada combinação de Gênero, Órgão e Cenário (Distância/Estabilidade), gera um gráfico log-linear.
    *   Eixo Y: Risco (ERR e LAR) em escala logarítmica.
    *   Eixo X: Distância (km).
    *   Diferenciação Visual: Marcadores distintos para cada Classe de Estabilidade (A-F).
*   **Produto:** Imagens PNG de alta resolução salvas na pasta `charts/`.

### 7. Saída de Dados (Output Layer)
*   **Arquivos Gerados:**
    *   `..._ERR.csv`: Matriz de Excesso de Risco Relativo (Adimensional). Fator de incremento sobre o risco natural.
    *   `..._LAR.csv`: Matriz de Risco Atribuível ao Longo da Vida (Probabilidade Absoluta).
    *   `charts/*.png`: Coleção de gráficos de risco por órgão.
*   **Rastreabilidade:** Um arquivo de Log (`.log`) é gerado simultaneamente, registrando cada passo da execução, modelo escolhido para cada célula e eventuais exceções matemáticas.
