# Documentação Adicional: Validação de Instalação e Ambiente

## Requisitos de Sistema

*   **Sistema Operacional:** Windows 10/11, Linux ou macOS.
*   **Linguagem:** Python 3.8 ou superior.
*   **Dependências:** Listadas em `requirements.txt` (pandas, flask, etc.).

## Procedimento de Teste de Instalação

Para garantir que o sistema está operando corretamente antes de processar dados reais de tese:

1.  **Verifique os arquivos de referência:** Certifique-se de que a pasta `dados_referencia` contém o arquivo `.csv` de parâmetros.
2.  **Teste de CLI:**
    Execute o comando no terminal:
    ```bash
    python hotspot_to_risk.py --input_dir "ExemploArquivoEntrada" --output_dir "saidas_teste" --exp_age 30 --att_age 30
    ```
    Verifique se na pasta `saidas_teste` foram criados 4 ou 5 arquivos.
3.  **Verifique o Log:** Abra o arquivo `.log` gerado e procure por linhas contendo "Risk:". Se houver valores numéricos (não NaN), o cálculo matemático está funcional.
4.  **Teste Web:** Execute `python app_web.py`, acesse `localhost:5000` e faça upload de um arquivo de teste.

Este procedimento garante a integridade operacional da ferramenta.
