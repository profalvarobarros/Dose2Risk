# Arquivos de Saída e Auditoria

O sistema Dose2Risk é determinístico na organização de seus outputs, garantindo que cada execução seja única, verificável e auditável.

A partir da versão 2.0, o sistema implementa um **Mecanismo de Rastreabilidade Cruzada** de nível militar, baseado em:
1.  **Integridade de Entrada:** Hash SHA-256 de todos os arquivos de input.
2.  **Rastreabilidade Granular:** Uso de `row_id` global para ligar CSV de resultado e Log de Auditoria.
3.  **Logs Estruturados:** Formato JSON estrito para ingestão por ferramentas de SIEM.

---

## Estrutura de Pastas e Nomenclatura

Os resultados são salvos em: `data/outputs/<id_execucao>/` (se via Web) ou no diretório especificado via CLI.

A nomenclatura dos arquivos segue o padrão:
`[Etapa]_[Descrição]_ee<IdadeExp>_ea<IdadeAtual>_<Timestamp>.<ext>`

Onde:
*   **ee**: *Age at Exposure* (Idade na Exposição).
*   **ea**: *Attained Age* (Idade Atingida/Atual).

---

## Detalhamento dos Arquivos

### 1. `1_hotspot_extract_... .csv` (Etapa 1: Extração)
*   **O que é:** O dado bruto extraído e "higienizado" do HotSpot.
*   **Novidade v2:** Inclui a coluna `row_id` sequencial para identificar univocamente cada registro extraído.
*   **Uso:** Auditoria primária dosimétrica.

### 2. `2_hotspot_transpose_... .csv` (Etapa 2: Transposição)
*   **O que é:** A matriz de doses preparada no formato Órgão x Cenario.
*   **Estrutura:**
    *   `row_id`: Identificador único da linha (órgão).
    *   `organ/...`: Nome do órgão/distância.
    *   Colunas de Cenário: Ex: `A_0.03`, `F_10.0`.
*   **Uso:** Verificação manual de doses agregadas por órgão.

### 3. `3_calculated_risks_ERR_LAR_... .csv` (Etapa 3: Cálculo de Risco)
Este é o arquivo principal de resultados. Ele foi **reformulado** para ser mais limpo e legível.

*   **Conteúdo:** Contém os cálculos de dose, risco relativo (ERR) e risco atribuível (LAR) para cada cenário.
*   **O que MUDOU na v2:**
    *   **Remoção de Poluição:** Colunas de parâmetros internadios (`latency`, `ddref`, `gamma`, etc.) foram removidas para facilitar a leitura.
    *   **Inclusão de `row_id`:** Primeira coluna do arquivo, servindo como chave para auditoria.
    *   **Colunas Dinâmicas (Filtros):** A presença das colunas de resultado (`dose_Sv_...`, `model_...`, `ERR_...`, `LAR_...`) agora é dinâmica.
        *   Se o usuário desmarcar "LAR", as colunas `LAR_...` não serão geradas.
        *   Se o usuário desmarcar "Feminino", linhas correspondentes serão omitidas.
        *   **Supressão de Segurança:** Se a opção "Mostrar campos com dose > 4 Sv" estiver desmarcada, cenários inteiros (todas as colunas associadas a uma distância/estabilidade) serão removidos do CSV se todos os órgãos apresentarem dose letal, mantendo o relatório focado em dados úteis.
    *   **Modelo por Cenário:** Cada cenário tem sua própria coluna de modelo (ex: `model_A_0.03`).

#### Exemplo de Colunas:
| row_id | sex | ... | dose_Sv_A_0.03 | model_A_0.03 | ERR_A_0.03 | LAR_A_0.03 | ... |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **10** | male | ... | 0.500 | BEIR_V | 0.12 | 0.005 | ... |

*(Na linha 10, cenário A_0.03, foi usado BEIR V)*

*(Na linha 10, cenário A_0.03, foi usado BEIR V)*

### 4. `charts/` (Visualização Gráfica)
**Novidade v2.1:** Geração automática de gráficos de risco.
*   **Localização:** Subpasta `charts/` dentro do diretório de saída.
*   **Formato:** Imagens PNG de alta resolução.
*   **Nomenclatura:** `Risk_Chart_[Órgão]_[Sexo]_[Idades].png`.
*   **Conteúdo do Gráfico:**
    *   Curvas de dose-resposta mostrando a evolução do risco com a distância.
    *   **Eixo Y:** Risco (ERR e LAR) em escala logarítmica.
    *   **Eixo X:** Distância da fonte (km).
    *   **Estilos:** Marcadores visuais distintos para identificar Classes de Estabilidade (A, B, C, D, E, F).

---

## 4. `4_execution_log_... .log` (Auditoria e Rastreabilidade)

Este é o "cérebro" da auditoria. Como o CSV foi limpo, todos os detalhes matemáticos foram movidos para cá.

### Mecanismo de Rastreabilidade
Para descobrir **exatamente** como um valor foi calculado no CSV:
1.  Olhe o **`row_id`** e o **Cenário** no arquivo CSV (ex: Linha **10**, Cenário **A_0.03**).
2.  Abra o arquivo de Log (`.log`).
3.  Busque por `"Row_ID": 10` e verifique o contexto `"Context": "...|A_0.03"`.

### Estrutura do AUDIT_LOG
Cada cálculo gera um registro JSON no log contendo:
*   **Context:** Gênero, Órgão e Cenário.
*   **Inputs:** Dose exata (Sv e mSv), Idades, Incidência Basal.
*   **Decisão:** Qual modelo foi escolhido e por quê.
*   **Equação:** A fórmula simbólica utilizada.
*   **Parâmetros Detalhados:** Todos os coeficientes ($\beta, \gamma, \eta, ddref, latency, etc.$) usados naquela conta específica.

#### Exemplo Real de Log:
```json
CALC_LOG: {
    "Row_ID": 10,
    "Context": "male|leukemia|A_0.03",
    "Dose_Sv": "5.0000e-01",
    "Model": "BEIR_V",
    "Equation": "ERR = (0.243 * dose_Sv + 0.271 * dose_Sv^2) * exp(4.885)",
    "Params": {
        "alpha2": 0.243,
        "alpha3": 0.271,
        "time_windows": [...],
        "Internal_Beta_V": 4.885
    },
    "Result_ERR": "1.2000e-01",
    "Result_LAR": "5.0000e-03"
}
```

#### Exemplo de Cálculo Abortado (Segurança/Filtro):
```json
CALC_LOG: {
    "Context": "male|thyroid|F_0.5",
    "Status": "SKIPPED",
    "Reason": "dose acima de 4000 mSv",
    "Dose_Sv": "5.20"
}
```

### Cabeçalho e Rodapé de Segurança
Para garantir **Não-Repúdio** e integridade da sessão, todo arquivo de log inicia e termina com metadados críticos:

**HEADER:**
```json
METADATA_HEADER: {
    "Event": "EXECUTION_START",
    "Inputs_Integrity": {
        "Dose_Matrix_Hash_SHA256": "a3f5...", 
        "Params_JSON_Hash_SHA256": "b7c9..."
    },
    ...
}
```

**FOOTER:**
```json
METADATA_FOOTER: {
    "Event": "EXECUTION_END",
    "Status": "SUCCESS"
}
```
A ausência do FOOTER indica que a execução foi abortada ou corrompida.

Isso garante que, mesmo com um CSV limpo, a auditoria matemática seja **completa e inequívoca**.
