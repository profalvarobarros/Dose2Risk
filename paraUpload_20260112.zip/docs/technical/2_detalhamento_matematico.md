# Detalhamento Matemático: Modelos de Risco e Algoritmo Híbrido

Este documento detalha o formalismo matemático e a lógica de seleção de modelos implementada no **Dose2Risk (v2.0)**. O sistema adota uma abordagem **Data-Driven**, onde todas as equações descritas abaixo são parametrizadas via configuração JSON, garantindo flexibilidade e rastreabilidade.

---

## 1. Lógica de Seleção Híbrida (BEIR V vs BEIR VII)

O Dose2Risk opera em modo **híbrido dinâmico** célula a célula, baseado na dose absorvida ($D$). Se o usuário não forçar um modelo específico, o sistema aplica um *Threshold de Decisão*:

$$
\text{Modelo}(D) =
\begin{cases}
\text{BEIR VII (Fase 2)} & \text{se } D < 100 \text{ mSv} \\
\text{BEIR V (1990)} & \text{se } D \ge 100 \text{ mSv}
\end{cases}
$$

*   **Justificativa:** O modelo BEIR VII é otimizado para baixas doses (< 100 mSv), incorporando o fator de redução DDREF ("Dose and Dose-Rate Effectiveness Factor"). Para altas doses, onde a linearidade com redução pode subestimar o risco agudo, ou onde o regime Linear-Quadrático do BEIR V é mais empiricamente validado (ex: Leucemia em sobreviventes de bombas atômicas), utilizamos o BEIR V.

---

## 2. Modelo BEIR VII (Baixas Doses)

Utilizado quando $D < 0.1 \text{ Sv}$. Baseia-se no relatório *BEIR VII Phase 2* (2006).

### 2.1 Forma Geral (Sólidos)
$$ ERR = \beta_s \cdot D \cdot \exp(\gamma \cdot e^*) \cdot \left(\frac{a}{60}\right)^\eta \cdot \frac{1}{\text{DDREF}} $$

**Parâmetros Configuráveis (via JSON):**
*   $\beta_s$: Coeficiente de risco (sexo-dependente).
*   $e^*$: Idade efetiva na exposição (penaliza jovens: $e^* = (e-30)/10$ se $e<30$).
*   $\gamma$: Modificador de idade na exposição.
*   $\eta$: Decaimento do risco com o envelhecimento.
*   **DDREF**: Fator de ajuste (Padrão: 1.5, exceto Mama/Tireoide = 1.0).

### 2.2 Forma Leucemia
Modelo Linear-Quadrático (LQ) com modulação temporal complexa:
$$ ERR = \beta_s D (1 + \theta D) \cdot \exp(\gamma e^* + \delta \ln(t/25) + \phi e^* \ln(t/25)) $$

---

## 3. Modelo BEIR V (Altas Doses)

Utilizado quando $D \ge 0.1 \text{ Sv}$. Baseado no relatório *BEIR V* (1990).
Diferente da v1.0, na v2.0 este modelo é totalmente parametrizável. Abaixo descrevemos as famílias de algoritmos suportadas:

### 3.1 Modelos Lineares (Geral)
Aplicado a Cânceres Respiratórios, Digestivos e Outros.
$$ ERR = C_{\text{sexo}} \cdot D $$
*   O coeficiente $C$ é lido do JSON (`beir_v` -> `linear`).
*   *Valores Padrão:* Pulmão (F: 0.63, M: 0.32), Digestivo (0.8), Outros (0.2).

### 3.2 Modelo Dependente da Idade (Mama)
$$ ERR = C(e) \cdot 2.0 \cdot D $$
*   Onde $C(e)$ varia conforme faixas etárias definidas no JSON (`age_brackets`).
*   *Padrão:* Coeficiente cai de 1.2 (crianças) para 0.1 (pós-menopausa).

### 3.3 Modelo Dependente da Idade (Tireoide)
$$ ERR = C(e) \cdot D $$
*   Modelo de "Threshold": Se $e < 18$, usa-se um coeficiente alto; senão, um baixo.
*   *Padrão:* Jovens (7.5), Adultos (0.5).

### 3.4 Leucemia (Regime de Alta Dose)
Modelo LQ puro com modificadores temporais discretos (Tabelas do BEIR V):
$$ ERR = (\alpha_2 D + \alpha_3 D^2) \cdot \exp(\beta_{tempo}) $$
*   Os parâmetros $\alpha_2$ e $\alpha_3$ são configuráveis no JSON. Os fatores temporais ($\beta$) seguem a lógica interna complexa do BEIR V.

---

## 4. Cálculo do Risco Atribuível (LAR)

O LAR aproxima a probabilidade absoluta de câncer induzido.
$$ LAR \approx ERR \times \text{Baseline Incidence}_{vida} $$

*   **Nota de Auditoria:** O valor exato da `Baseline Incidence` utilizada para cada célula pode ser auditado no arquivo de Log (`4_execution_log.log`), no campo `"Params" -> "Baseline_Incidence"`.

---

## 5. Rastreabilidade Matemática no Log

Devido à natureza dinâmica do algoritmo, o arquivo `4_execution_log...log` agora exibe a fórmula simbólica exata e os coeficientes usados para **cada célula**, permitindo auditoria "Caixa Branca":

```json
"Computed": {
    "Model": "BEIR_V",
    "Equation": "ERR = 7.5 * dose_Sv",
    "Params": { "coef_young": 7.5, "threshold_age": 18 }
}
```
