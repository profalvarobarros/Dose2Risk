# Arquivo de Parametrização: Estrutura JSON e Flexibilidade (v2.0)

O "cérebro" biológico do Dose2Risk reside agora no arquivo de configuração **JSON**: `config/beir_hotspot_parameters.json`.

Diferente das versões anteriores (v1.x) que utilizavam tabelas planas (CSV) e coeficientes fixos no código (`hardcoded`), a versão 2.0 adota uma arquitetura **Data-Driven**. Isso significa que **toda** a matemática dos modelos BEIR V e BEIR VII é controlada por este arquivo, permitindo atualizações científicas (ex: novos dados do INCA, revisão dos coeficientes do BEIR) sem necessidade de alterar uma única linha de código Python.

---

## Estrutura do JSON

O arquivo segue o padrão JSON Schema, com uma chave raiz `configurations` que contém um dicionário de órgãos.

```json
{
  "_metadata": {
    "version": "2.0",
    "description": "Biological Risk Parameters...",
    "last_update": "YYYY-MM-DD"
  },
  "configurations": {
    "NOME_DO_ORGAO_HOTSPOT": {
      "hotspot_organ": "...",
      "beir_VII_equivalence": "...",
      "baseline_incidence": { "M": 0.0, "F": 0.0 },
      "beir_vii": { ... },
      "beir_v": { ... }
    }
  }
}
```

---

## Detalhamento dos Campos

### 1. Identificação e Mapeamento
*   **Chave do Objeto (ex: `lung`)**: Deve corresponder exatamente ao nome da coluna de dose gerada pelo software HotSpot.
*   **`beir_VII_equivalence`**: Mapeia o órgão do HotSpot para a categoria epidemiológica do BEIR VII (ex: `stomach_wall` -> `stomach`).

### 2. Incidência Basal (`baseline_incidence`)
Define a probabilidade vitalícia natural de desenvolver o câncer específico naquela população.
*   **`M`**: Taxa para homens (0.0 a 1.0).
*   **`F`**: Taxa para mulheres (0.0 a 1.0).
*   *Fonte Padrão:* Estimativas do INCA 2023.

### 3. Bloco `beir_vii` (Baixas Doses)
Controla os parâmetros da equação do BEIR VII (Fase 2).
*   **`model_type`**: `solid` ou `leukemia`.
*   **`params`**:
    *   `beta` ($\beta$): Coeficiente linear de risco. Pode ser um número único ou um objeto `{ "M": ..., "F": ... }`.
    *   `gamma` ($\gamma$): Modificador de idade na exposição.
    *   `eta` ($\eta$): Decaimento com a idade atingida.
    *   `ddref`: Fator de eficácia (divisor de risco).
    *   `theta`, `delta`, `phi`: Parâmetros específicos para Leucemia.

### 4. Bloco `beir_v` (Altas Doses)
Controla os parâmetros da equação do BEIR V (1990). **Novo na v2.0.**
*   **`model_type`**: Define qual algoritmo usar.
    *   `leukemia_lq`: Modelo Linear-Quadrático complexo.
    *   `breast_age_dependent`: Modelo linear com coeficientes variáveis por faixa etária.
    *   `thyroid_age_dependent`: Modelo com alta sensibilidade para crianças.
    *   `linear`, `linear_digestive`, `linear_other`: Modelos lineares simples ($ERR = \text{Coef} \times D$).
*   **`params`**:
    *   `coef`: Coeficiente linear simples.
    *   `age_brackets`: Lista de faixas etárias e seus coeficientes (para Mama).
    *   `coef_young`/`coef_adult`: Para Tireoide.

---

## Exemplo Real (Tireoide)

```json
"thyroid": {
  "hotspot_organ": "thyroid",
  "beir_VII_equivalence": "thyroid",
  "baseline_incidence": { "M": 0.0014, "F": 0.0050 },
  
  "beir_vii": {
    "model_type": "solid",
    "latency": 5,
    "ddref": 1.0, 
    "params": {
      "gamma": -0.083,
      "eta": 0.0,
      "beta": { "M": 0.53, "F": 1.05 }
    }
  },
  
  "beir_v": {
    "model_type": "thyroid_age_dependent",
    "params": {
      "threshold_age": 18,
      "coef_young": 7.5,
      "coef_adult": 0.5
    }
  }
}
```

**Interpretação:**
*   Em baixas doses (**BEIR VII**), usa-se DDREF=1 (sem redução) e $\beta$ diferenciado por sexo.
*   Em altas doses (**BEIR V**), se a vitima tiver < 18 anos, o risco é **7.5x** a dose; se adulto, apenas **0.5x**.

---

## Procedimento de Atualização Científica

Para atualizar os parâmetros (ex: publicação do BEIR VIII):
1.  Abra o arquivo `.json` em um editor de texto ou IDE.
2.  Localize o órgão desejado.
3.  Altere os valores numéricos em `params`.
4.  Reinicie a aplicação (o JSON é carregado a cada execução).
**Não é necessário** recompilar ou editar arquivos `.py`.
