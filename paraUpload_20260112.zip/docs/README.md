# Documentação Oficial: Dose2Risk

Bem-vindo à documentação do **Dose2Risk**, um sistema computacional para estimativa de Risco Radiológico Biológico (Câncer) induzido por exposições agudas ou crônicas, baseado nos relatórios BEIR (Biological Effects of Ionizing Radiation).

---

## 🏗️ Estrutura da Documentação

Para facilitar a avaliação técnica e científica, a documentação está organizada em três pilares principais:

### 1. Documentação Técnica (`/technical`)
Focada na implementação de software, arquitetura, algoritmos e configurações.
*   [**Fluxo do Sistema**](technical/1_fluxo_macro_do_sistema.md): Visão geral da arquitetura de dados (ETL).
*   [**Detalhamento Matemático**](technical/2_detalhamento_matematico.md): As equações diferenciais e a lógica híbrida (BEIR V/VII) implementadas.
*   [**Parametrização (JSON)**](technical/3_arquivo_parametrizacao.md): Guia de configuração dos modelos biológicos (`config/*.json`).
*   [**Arquivos de Saída**](technical/4_arquivos_de_saida.md): Dicionário de dados dos relatórios gerados.
*   [**Verificação e Validação**](technical/7_verificacao_e_validacao.md): Procedimentos de garantia da qualidade e integridade.

### 2. Documentação Científica (`/scientific`)
Focada na física médica, justificativas metodológicas e referências cruzadas.
*   [**Análise Metodológica**](scientific/analise_metodologica.md): Discussão sobre a escolha dos modelos.
*   [**Relatório Físico-Nuclear**](scientific/relatorio_fisico_nuclear.md): Contexto radiológico.

### 3. Base Teórica (`/theoretical_base`)
Material de referência primária utilizado para construir o software.
*   Relatórios BEIR originais (PDFs/Resumos).
*   Planilhas de coeficientes de referência.
*   **Relatórios de Auditoria**: Histórico de avaliações do código.

---

## 🚀 Guia Rápido

### Instalação
O sistema é escrito em Python 3.9+. Requer as dependências listadas em `requirements.txt`.
```bash
pip install -r requirements.txt
python run.py
```

### Configuração
O comportamento numérico do sistema é governado pelo arquivo:
`config/beir_hotspot_parameters.json`

### Auditoria
Cada execução gera um log detalhado em `data/outputs/`, permitindo rastrear exatamente qual fórmula foi usada para cada indivíduo e cenário.

---

## 📅 Versionamento

Consulte o [CHANGELOG](CHANGELOG.md) para o histórico de evoluções do software (v1.0 -> v2.0).

---
*Documentação gerada e mantida pela equipe de desenvolvimento Dose2Risk.*
*Última atualização: Dezembro/2025.*
