# Changelog - Dose2Risk

Todas as mudanças notáveis neste projeto serão documentadas neste arquivo.

## [v2.0.0] - 2025-12-17

### Adicionado
- **Seleção Híbrida de Modelo:** O sistema agora seleciona automaticamente entre BEIR VII (Dose < 100 mSv) e BEIR V (Dose >= 100 mSv) por cenário.
- **Rastreabilidade Cruzada (Row ID):** Introdução da coluna `row_id` (ou `id_linha`) em todos os CSVs de saída (`execute`, `transpose`, `risk`) e nos Logs de execução.
- **Audit Log Detalhado:** O arquivo de log agora contém registros JSON (`AUDIT_LOG`) com todos os parâmetros matemáticos usados para calcular cada célula do CSV.

### Alterado
- **Estrutura do CSV de Risco:**
    - Removidas colunas de parâmetros técnicos (`latency`, `ddref`, `gamma`, `eta`, etc.) para "limpar" o arquivo.
    - O modelo utilizado agora é reportado por coluna de cenário (ex: `model_A_0.03`) em vez de uma coluna agregada global.
    - Colunas de identificação de órgão (`hotspot_organ`, `beir_VII_organ_equivalence`) movidas para o início do arquivo.
- **Documentação:** Atualizados manuais técnicos de Arquivos de Saída e Detalhamento Matemático.

### Corrigido
- Correção na lógica de atribuição de modelos onde cenários de alta dose poderiam ser mascarados se o último cenário fosse de baixa dose.
- Correção de dependência ausente (`flask-babel`).

---

## [v1.0.0] - 2025-12-11
- Versão inicial do sistema com extração HotSpot, transposição e cálculo BEIR VII básico.
