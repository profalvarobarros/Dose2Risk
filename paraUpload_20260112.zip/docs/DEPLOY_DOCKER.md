# Guia de Implantação com Docker (Hostinger VPS)

Este guia cobre a instalação e execução do **Dose2Risk** usando Docker. Este método é ideal para VPS, garantindo que o ambiente seja idêntico ao de desenvolvimento.

## 1. Pré-requisitos
*   VPS na Hostinger (Ubuntu 20.04/22.04 recomendado).
*   Acesso SSH ao servidor.

## 2. Instalar Docker e Docker Compose no Servidor

Conecte-se ao seu VPS via SSH e execute:

```bash
# Atualizar lista de pacotes
sudo apt update
sudo apt upgrade -y

# Instalar Docker
sudo apt install docker.io -y

# Iniciar e habilitar o Docker
sudo systemctl start docker
sudo systemctl enable docker

# Instalar plugin Docker Compose (v2)
sudo apt install docker-compose-plugin -y
```

## 3. Implantação

### Passo 1: Clonar o Repositório
```bash
cd /var/www
git clone https://github.com/profalvarobarros/Dose2Risk.git
cd Dose2Risk
```

### Passo 2: Construir e Iniciar os Containers
Na raiz do projeto (onde está o `docker-compose.yml`):

```bash
# O comando 'up -d' sobe os containers em background (detached mode)
# O '--build' garante que a imagem seja recriada com as alterações mais recentes
sudo docker compose up -d --build
```

Agora sua aplicação deve estar rodando em `http://IP_DO_SEU_VPS:8000`.

## 4. (Opcional) Configurar Nginx como Reverse Proxy
Para acessar via domínio (ex: `dose2risk.com`) e usar a porta 80/443 padrão.

1.  **Instalar Nginx:** `sudo apt install nginx -y`
2.  **Criar Configuração:** `sudo nano /etc/nginx/sites-available/dose2risk`

Coloque o seguinte conteúdo:
```nginx
server {
    listen 80;
    server_name seu_dominio.com www.seu_dominio.com;

    location / {
        proxy_pass http://localhost:8000; # Aponta para a porta do Docker
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

3.  **Ativar e Reiniciar:**
```bash
sudo ln -s /etc/nginx/sites-available/dose2risk /etc/nginx/sites-enabled
sudo nginx -t
sudo systemctl restart nginx
```

## 5. Comandos Úteis

*   **Ver status dos containers:** `sudo docker compose ps`
*   **Ver logs da aplicação:** `sudo docker compose logs -f`
*   **Parar aplicação:** `sudo docker compose down`
*   **Atualizar aplicação:**
    ```bash
    git pull
    sudo docker compose up -d --build
    ```
