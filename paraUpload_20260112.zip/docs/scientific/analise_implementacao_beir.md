# Análise de Conformidade: Implementação Computacional vs Base Teórica

**Documento Referência:** *Evaluating the health impacts of two extreme-releasing radiological hypothetical events* (Souza et al., 2025)
**Artefato Analisado:** `dose2risk/core/risk_calculator.py`

---

## 1. Resumo Executivo

A inspeção do código-fonte do módulo `CalculadoraRisco` confirma que a implementação do software **replica fielmente** a metodologia híbrida de avaliação de risco radiológico descrita no artigo científico referenciado. O algoritmo incorpora exatamente as equações, os critérios de transição entre modelos e os parâmetros biológicos citados na fundamentação teórica.

## 2. Detalhamento da Verificação

A análise foi segmentada nos três pilares metodológicos apresentados no artigo:

### 2.1. Arquitetura Híbrida e Critério de Decisão
O artigo estabelece uma abordagem dual para o cálculo de risco, dependente da magnitude da dose recebida (TEDE):
*   **Baixas Doses (< 100 mSv):** Utilização do modelo BEIR VII (Fase 2).
*   **Altas Doses (≥ 100 mSv):** Utilização do modelo BEIR V (1990).

**Na Implementação (`risk_calculator.py`):**
O método `calculate` (linhas 599-602) implementa explicitamente este limiar de decisão:
```python
if self.model == 'auto':
    limit_mSv = 100
    dose_mSv = dose_Sv * 1000
    modelo = 'vii' if dose_mSv < limit_mSv else 'v'
```
Esta lógica garante que o software selecione automaticamente a base matemática correta conformando-se à metodologia do artigo.

### 2.2. Modelo BEIR VII - Leucemia
O artigo apresenta a **Equação (4)** para estimativa de risco de Leucemia em baixas doses:
> $ERR = \beta_s D(1 + \theta D) \exp(\gamma e^* + \delta \ln(t/25) + \phi e^* \ln(t/25))$

**Na Implementação:**
O método `beir_vii_risk` (bloco `else` para Leucemia, linhas 128-150) traduz esta fórmula matemática ipsis litteris:
1.  **Componente da Dose:** `beta * D * (1 + theta * D)`
2.  **Componente Temporal/Etária:** `exp(gamma * e_star + delta * log(t / 25) + phi * e_star * log(t / 25))`
3.  **Definição de $e^*$:** O código calcula `e_star = (exposure_age - 30)/10` (linhas 552-555), exatamente como definido na legenda da Equação (4) do artigo.

### 2.3. Modelo BEIR V - Leucemia
Para altas doses, o artigo cita as **Equações (2) e (3)**, que descrevem um modelo Linear-Quadrático (LQ) modulado por janelas temporais:
> $ERR = (\alpha_1 D + \alpha_2 D^2) \exp(\beta)$

Onde $\beta$ assume valores distintos (ex: 4.885, 2.367) dependendo do tempo decorrido desde a exposição.

**Na Implementação:**
O método `beir_v_risk` (linhas 212-267) implementa esta estrutura:
*   Utiliza os coeficientes `ALPHA2` e `ALPHA3` (correspondentes a $\alpha_1$ e $\alpha_2$) para o termo quadrático: `(ALPHA2 * D + ALPHA3 * D**2)`.
*   Aplica `math.exp(beta)` como multiplicador.
*   Implementa a lógica de seleção do coeficiente $\beta$ baseada em janelas de tempo (`time_windows`), suportando os valores exatos citados no artigo (4.885 para $t \le 15$ e 2.367 para janelas posteriores), garantindo consistência com os resultados apresentados no estudo.

## 3. Conclusão da Análise

O arquivo `dose2risk/core/risk_calculator.py` **está validado**.

A verificação demonstra que o código não apenas utiliza os mesmos coeficientes numéricos, mas estrutura a lógica de programação para espelhar a "física" dos modelos BEIR V e VII conforme detalhado por Souza et al. (2025). O tratamento híbrido (switch de 100 mSv) é o ponto central de conformidade que alinha a ferramenta computacional à estratégia de avaliação de risco proposta no artigo.
