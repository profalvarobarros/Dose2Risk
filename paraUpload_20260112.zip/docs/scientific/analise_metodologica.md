# Relatório de Análise Metodológica e de Código: Dose2Risk

**Data:** 2025-12-11
**Projeto:** Dose2Risk - Programa_Python_AR
**Arquivo Analisado:** `hotspot_to_risk.py`, `app_web.py`, e dados de referência.

## 1. Resumo Executivo

O sistema `Dose2Risk` propõe uma pipeline automatizada para converter saídas do software HotSpot em estimativas de risco de câncer induzido por radiação, utilizando modelos baseados nos relatórios BEIR V e BEIR VII.

**Veredito Geral:** O código está bem estruturado, segue boas práticas de engenharia de software (modularização, logging, tratamento de erros) e implementa corretamente a maior parte da lógica matemática do BEIR VII para baixas doses. No entanto, foram identificadas **inconsistências metodológicas significativas** no tratamento de altas doses (modelo BEIR V) e na configuração de parâmetros via CSV versus regras hardcoded.

---

## 2. Análise de Código e Estrutura

### Pontos Positivos
*   **Modularização:** O uso de classes (`ExtratorHotspot`, `TranspositorHotspot`, `CalculadoraRisco`) facilita a manutenção e testes.
*   **Robustez na Leitura de Dados:** O método `parse_number` e as expressões regulares lidam bem com diferentes formatos numéricos (vírgulas e pontos), crucial para evitar erros com configurações regionais diferentes.
*   **Rastreabilidade:** O sistema gera logs detalhados de execução, o que é excelente para auditoria científica.
*   **Pipeline Web:** A integração com Flask é limpa e funcional, validando arquivos de entrada antes do processamento.

### Pontos de Atenção (Código)
*   **Função `beir_v_risk`:** A função recebe um argumento `beta`, mas **não o utiliza**. Ela confia inteiramente em parâmetros hardcoded dentro da função (`BETA_V_PARAMS`), ignorando qualquer especificidade do órgão que poderia vir via parâmetro.

---

## 3. Análise Metodológica

### 3.1. Modelo BEIR VII (Baixas Doses / < 100 mSv)
A implementação do BEIR VII parece metodologicamente correta e alinhada com as equações padrão para Excesso de Risco Relativo (ERR).
*   **Equações:** A implementação de `ERR = beta * D * exp(...)` está correta.
*   **Latência e Ajuste de Idade ($e^*$):** A lógica de $e^*$ (idade de exposição ajustada) implementada segue o relatório BEIR VII.
*   **Leucemia:** A fórmula específica para leucemia foi implementada corretamente.

### 3.2. Modelo BEIR V (Altas Doses / >= 100 mSv) - **CRÍTICO**
Aqui reside a maior inconsistência metodológica identificada.
*   **Problema de Generalização:** Quando a dose excede 100 mSv, o código alterna para o modelo BEIR V (linha 400 do `hotspot_to_risk.py`). No entanto, a implementação de `beir_v_risk` utiliza coeficientes `ALPHA2` e `ALPHA3` fixos e parâmetros `BETA` fixos **para todos os casos**.
*   **Impacto:** Isso significa que, para altas doses, o sistema calcula **exatamente o mesmo risco para qualquer órgão** (Tireoide, Pulmão, Fígado, etc.), ignorando a radiossensibilidade específica de cada tecido. Metodologicamente, isso está incorreto, pois o risco de câncer em altas doses continua sendo dependente do órgão.
*   **Obsolescência:** O uso do BEIR V (1990) como fallback para altas doses é questionável dado que o BEIR VII (2006) é o padrão mais atual. Embora o BEIR VII foque em baixas doses (extrapolação LNT), seus modelos de base são derivados do Life Span Study (LSS) que inclui altas doses. A menos que haja um requisito específico para usar BEIR V, o BEIR VII costuma ser preferível.

### 3.3. Fator de Efetividade da Dose (DDREF)
*   **Inconsistência Configuração vs Código:** O arquivo CSV de parâmetros (`beirVII_hotspot_organ_equivalance_parameters.csv`) define um DDREF de `1.5` para a `thyroid` (tireoide). Porém, no código (`hotspot_to_risk.py`, linhas 236-239), existe uma regra *hardcoded* que **impede** a aplicação do DDREF para tireoide e mama, dividindo o risco por 1 (ou não dividindo), independentemente do que está no CSV.
    *   *Recomendação:* Remova a regra hardcoded e controle isso exclusivamente via CSV (definindo valor 1.0 no arquivo), ou documente claramente essa exceção.

### 3.4. Interpretação da Dose (HotSpot)
*   O sistema extrai a "Committed Dose Equivalent" (Dose Comprometida) do HotSpot e a aplica como uma dose aguda na `idade de exposição`.
*   **Análise:** Isso é uma aproximação conservadora válida para fins de triagem ou emergência (assume-se que todo o risco futuro daquela dose é "pago" no momento do acidente). No entanto, para fins epidemiológicos precisos, tratar dose comprometida (recebida ao longo de 50 anos) como dose aguda pode superestimar o risco imediato ou alterar a projeção de risco vitalício.

## 4. Recomendações de Correção

1.  **Corrigir a Implementação do BEIR V (ou remover):** Se o suporte a altas doses é necessário, deve-se implementar coeficientes específicos por órgão para o modelo quadrático/linear-quadrático, ao invés de usar uma fórmula genérica para todos. Alternativamente, considere usar o modelo BEIR VII para todas as faixas de dose, com as devidas ressalvas sobre linearidade em altas doses.
2.  **Unificar a Lógica do DDREF:** Remova a verificação `if orgao not in ['tireoide'...]` do código Python e ajuste o arquivo CSV para que Tireoide e Mama tenham `ddref = 1.0`. Isso torna o sistema mais transparente e configurável.
3.  **Esclarecer a Saída:** O arquivo de saída contém o **Excesso de Risco Relativo (ERR)** (ou similar). É importante deixar claro para o usuário final que esse valor não é a "Probabilidade de Câncer" (Lifetime Attributable Risk - LAR) absoluta, a menos que seja multiplicado pelas taxas basais de incidência da população (que parecem não estar sendo usadas, já que `baseline_rate` é `None` na maioria das chamadas).

## 5. Conclusão

O sistema é robusto do ponto de vista de programação, mas requer revisão na lógica científica de "fallback" para altas doses. Se o objetivo é publicar ou usar em cenários reais, a generalização do modelo BEIR V para todos os órgãos deve ser corrigida imediatamente.

---

## 6. Addendum: Atualizações da Versão 2.1 (Janeiro/2026)

Em resposta à análise acima, a versão 2.1 do Dose2Risk implementou as seguintes correções e evoluções metodológicas:

1.  **Correção do Modelo Híbrido:** A alternância entre BEIR VII (baixa dose) e BEIR V (alta dose) agora é totalmente funcional e parametrizada por órgão. As generalizações incorretas apontadas no item 3.2 foram solucionadas através da nova arquitetura orientada a dados (JSON).
2.  **Limite de Segurança (4 Sv):** Foi introduzido um limite superior rígido de 4 Sv (4000 mSv) para o cálculo de risco estocástico.
    *   *Justificativa:* Doses acima deste patamar entram no regime de efeitos determinísticos agudos (ex: Síndrome Aguda da Radiação), onde a mortalidade a curto prazo compete com o risco de câncer tardio. Calcular LAR para indivíduos com alta probabilidade de óbito imediato é metodologicamente inválido. O sistema agora aborta o cálculo (output "N/A" e Log `SKIPPED`) para esses cenários.
3.  **Filtragem de Dados:** A interface agora permite a filtragem granular de sexo e órgãos, permitindo análises direcionadas e reduzindo o "ruído" nos relatórios de saída.
