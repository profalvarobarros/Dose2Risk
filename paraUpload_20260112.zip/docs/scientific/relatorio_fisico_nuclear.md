# Relatório Técnico de Validação Radiobiológica: Sistema Dose2Risk

**Autor:** Especialista em Física Nuclear e Radiobiologia
**Data:** 11 de Dezembro de 2025
**Escopo:** Análise metodológica, dosimétrica e matemática do pipeline computacional.

---

## 1. Introdução e Objetivo

Este documento apresenta uma auditoria técnica do sistema `Dose2Risk`, desenhado para estimar riscos estocásticos (indução de câncer) a partir de inputs dosimétricos do código HotSpot. A análise segue os princípios da proteção radiológica moderna, baseada nas publicações da *National Academy of Sciences* (BEIR V e BEIR VII).

## 2. Análise do Fluxo Dosimétrico (Input)

**O Problema da Dose Comprometida (CDE):**
O sistema recebe como entrada a *Committed Dose Equivalent* (CDE) calculada pelo HotSpot. A CDE é a integral da taxa de dose no tecido por 50 anos após a incorporação.

*   **Tratamento no Sistema:** O código aplica o valor total da CDE como uma dose aguda recebida inteiramente na `idade de exposição` ($age_{exp}$).
*   **Parecer Científico:**
    *   *Para Cânceres Sólidos (Latência 5-10 anos):* Esta é uma aproximação conservadora válida (Princípio ALARA). Assume-se que o dano é "pago à vista".
    *   *Para Leucemia (Latência ~2 anos):* Há uma superestimação do risco. Como a dose é entregue lentamente ao longo de décadas, tratar a CDE de 50 anos como instantânea ignora que parte da dose ocorrerá *após* a janela temporal crítica de indução da leucemia.
    *   **Veredito:** Aceitável para fins de triagem conservadora, mas deve ser documentado nas limitações do sistema como "Maximização de Risco".

## 3. Análise do Modelo de Transição (O Limiar de 100 mSv)

O sistema implementa um "switch" metodológico:
*   $D < 100$ mSv $\rightarrow$ **BEIR VII (2006)**
*   $D \ge 100$ mSv $\rightarrow$ **BEIR V (1990)**

**Fundamentação:**
Esta abordagem híbrida tenta mitigar a incerteza do modelo Linear Sem Limiar (LNT) em altas doses, recorrendo aos modelos Lineares-Quadráticos (LQ) do BEIR V, que foram ajustados com dados de doses mais altas. Embora o BEIR VII seja o consenso atual, a preservação do BEIR V para altas doses é uma escolha de design válida para comparar metodologias clássicas vs. modernas.

## 4. Auditoria Matemática dos Modelos

### 4.1. Baixas Doses: BEIR VII
A implementação verificada no código (`base_vii_risk`) calcula o **ERR (Excess Relative Risk)**.

*   **Cânceres Sólidos:**
    $$ERR = \beta \cdot D \cdot \exp(\gamma e^*) \cdot (a/60)^\eta$$
    *   *Verificação:* O código implementa corretamente a dependência da idade atingida ($a$) e idade de exposição ajustada ($e^*$).
    *   *DDREF:* A aplicação do *Dose and Dose-Rate Effectiveness Factor* de 1.5 para sólidos (exceto mama/tireoide) está correta conforme a recomendação do BEIR VII para transpor dados agudos de alta dose (LSS) para baixas doses. A correção recente para setar DDREF=1.0 para Tireoide/Mama via CSV foi crucial e está correta.

*   **Leucemia:**
    $$ERR = \beta \cdot D \cdot (1 + \theta D) \cdot \exp(\dots)$$
    *   *Verificação:* A equação linear-quadrática foi mantida, o que é mandatório para tecido hematopoiético. A ausência de DDREF para leucemia no código está correta (o modelo já incorpora a curvatura LQ).

### 4.2. Altas Doses: BEIR V
A implementação recente corrige o erro grave de generalização. A nova lógica segmenta por radiossensibilidade tecidual:

*   **Medula Óssea (Leucemia):** Aplica o modelo LQ ($0.243D + 0.271D^2$). **Correto.** O termo quadrático domina em altas doses.
*   **Vias Respiratórias:** Diferenciação por sexo (mulheres com maior risco relativo). **Correto** conforme Tabela 4-2 do BEIR V.
*   **Tireoide:** Forte dependência da idade (<18 anos vs Adultos). **Correto**, reflete a extrema sensibilidade da glând em desenvolvimento (efeito de iodo radioativo).
*   **Mama:** Modelo linear com decaimento do risco conforme a idade de exposição avança. **Correto**.

## 5. Inconsistência Remanescente e Ponto de Atenção

Apesar das correções matemáticas, resta uma **ambiguidade de interpretação** que é crítica para um sistema científico:

### A Unidade de Saída (ERR vs LAR)
O código retorna um valor numérico chamado "Risco".
*   As equações do BEIR VII calculam o **ERR (Excess Relative Risk)** ou **EAR (Excess Absolute Risk)** dependendo do órgão, mas o código atual trata tudo como coeficientes de ERR multiplicativos.
*   **A Inconsistência:** O usuário final (não físico) pode ler um resultado de `0.1` como "10% de probabilidade de ter câncer".
*   **A Realidade:** Um ERR de `0.1` significa que o risco daquela pessoa aumentou em 10% *em relação ao risco basal* dela. Se o risco basal de câncer naquela idade for 0.5%, o risco total passa a ser $0.5\% \times (1 + 0.1) = 0.55\%$.

**Recomendação Científica:**
O sistema deve explicitar que o Output é **ERR (Excesso de Risco Relativo)** e, idealmente, multiplicar esse valor pela *Baseline Rate* (Taxa Basal) para entregar o **LAR (Lifetime Attributable Risk)**, que é a verdadeira "probabilidade de ter câncer devido à dose".

Como a função `baseline_rate` muitas vezes é passada como `None` no código atual, o software está entregando apenas o **Fator de Aumento**, não a probabilidade absoluta.

## 6. Conclusão da Auditoria

O sistema `Dose2Risk` (após as correções aplicadas em 11/12/2025) encontra-se estavelmente fundamentado nas metodologias BEIR V e VII.
1.  As equações matemáticas refletem os relatórios.
2.  A lógica de seleção de modelo é coerente com o limiar de 100 mSv.
3.  A distinção de órgãos no BEIR V foi sanada.

**Aprovação:** O sistema está apto para uso científico, *desde que* os usuários sejam informados de que os resultados numéricos representam o **Excesso de Risco Relativo (ERR)** e pressupõem entrega aguda da dose comprometida.
