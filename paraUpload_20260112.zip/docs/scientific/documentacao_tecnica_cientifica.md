# Documentação Técnica e Metodológica: Sistema Dose2Risk

## 1. Visão Geral do Sistema

O **Dose2Risk** é uma pipeline computacional desenvolvida para converter dados dosimétricos de dispersão atmosférica de radionuclídeos (gerados pelo software HotSpot Health Physics Codes, versão 3.1.2) em estimativas probabilísticas de risco de câncer induzido por radiação.

O sistema opera sob uma arquitetura de pós-processamento, integrando os modelos epidemiológicos BEIR VII (Board on Radiation Effects Research, 2006) para baixas doses e BEIR V (1990) para altas doses, oferecendo uma abordagem híbrida robusta para cenários de exposição nuclear.

---

## 2. Fluxo de Dados e Processamento

O processamento ocorre em três estágios sequenciais: Extração (Parsing), Transposição e Cálculo de Risco.

### 2.1. Estágio 1: Extração de Dados Dosimétricos
O módulo `ExtratorHotspot` lê os arquivos de texto (`.txt`) gerados pelo HotSpot ("General Plume Output") e extrai estruturadamente as variáveis da simulação.

#### 2.1.1 Tratamento da Dose Comprometida (CDE)
O HotSpot fornece a **Committed Dose Equivalent (CDE)**, que representa a dose integrada em 50 anos após a inalação.
*   **Premissa Metodológica:** O sistema Dose2Risk trata a CDE total como uma **dose aguda** recebida integralmente na idade de exposição ($Age_{exp}$).
*   **Justificativa e Limitações:** Esta abordagem é conservadora para proteção radiológica. Assume que todo o risco associado à incorporação é atribuído ao momento do acidente. Para tecidos de alta renovação (como medula óssea), isso pode superestimar o risco se a meia-vida biológica do radionuclídeo for longa.

---

## 3. Metodologia de Cálculo de Risco

### 3.1. Estratégia Híbrida de Seleção de Modelo
O sistema implementa um limiar de decisão (*decision boundary*) baseado na dose absorvida ($D$) no tecido:

*   **Se $D < 100 \text{ mSv}$ ($0.1 \text{ Sv}$):** Aplica-se o modelo **BEIR VII**.
    *   *Fundamentação:* Baseado na extrapolação linear sem limiar (LNT) recomendada para doses tipicamente encontradas em proteção radiológica e ambiental.
*   **Se $D \ge 100 \text{ mSv}$ ($0.1 \text{ Sv}$):** Aplica-se o modelo **BEIR V**.
    *   *Fundamentação:* Utiliza modelos lineares-quadráticos ou lineares ajustados para altas doses (derivados diretamente dos sobreviventes de Hiroshima/Nagasaki sem a suavização para baixas doses), capturando melhor a não-linearidade em exposições agudas severas.

---

### 3.2. Modelo BEIR VII (Baixas Doses)

O sistema calcula o **Excesso de Risco Relativo (ERR)** usando as equações paramétricas da Tabela 12D-1 e 12D-2 do relatório BEIR VII (2006).

#### 3.2.1 Equação Geral para Cânceres Sólidos
$$ERR(D, s, a, e) = \beta_s \cdot D \cdot \exp(\gamma \cdot e^*) \cdot \left(\frac{a}{60}\right)^\eta \cdot \frac{1}{\text{DDREF}}$$
Onde:
*   $D$: Dose absorvida no órgão (Sv).
*   $\beta_s$: Coeficiente de inclinação específico por sexo (M/F).
*   $a$: Idade atingida (assessment age).
*   $e$: Idade na exposição.
*   $e^*$: Termo de ajuste de idade ($e^* = (e - 30)/10$ se $e < 30$, senão $0$).
*   $\gamma$: Coeficiente de efeito da idade na exposição (negativo, indicando maior risco para jovens).
*   $\eta$: Coeficiente de efeito da idade atingida (geralmente negativo, o risco relativo cai com a idade).
*   **DDREF (Dose and Dose-Rate Effectiveness Factor):** Fator de 1.5 aplicado para converter riscos de altas taxas para baixas taxas de dose.
    *   *Exceção:* Para **Tireoide** e **Mama**, DDREF = 1.0 (linearidade pura assumida), conforme parametrizado no sistema.

#### 3.2.2 Equação para Leucemia
O modelo é Linear-Quadrático (LQ) e inclui o tempo desde a exposição ($t = a - e$):
$$ERR = \beta_s \cdot D \cdot (1 + \theta \cdot D) \cdot \exp\left[\gamma \cdot e^* + \delta \cdot \ln(t/25) + \phi \cdot e^* \cdot \ln(t/25)\right]$$
*   Nota: Não se aplica DDREF para leucemia, pois o termo quadrático $(1 + \theta D)$ já modela a curvatura da resposta dose-efeito.

---

### 3.3. Modelo BEIR V (Altas Doses)

Para doses acima de 100 mSv, o sistema abandona a generalização e aplica modelos específicos por órgão (BEIR V, 1990), reconhecendo que a resposta biológica em altas doses varia drasticamente entre tecidos.

#### 3.3.1 Leucemia (Medula Óssea)
Modelo Linear-Quadrático com forte dependência temporal:
$$ERR = (0.243 D + 0.271 D^2) \cdot \exp(\beta_{tempo})$$
*   Os parâmetros $\beta_{tempo}$ variam conforme o tempo decorrido ($t$) e idade na exposição (jovens vs adultos), refletindo a onda de leucemias que ocorre 5-15 anos pós-exposição e depois decai.

#### 3.3.2 Câncer de Mama
Modelo Linear com dependência etária inversa:
$$ERR = C(e) \cdot D$$
*   O coeficiente $C(e)$ decresce conforme a mulher envelhece na data da exposição. O risco é máximo para expostas < 15 anos.
*   O sistema zera o risco de mama se o sujeito for masculino.

#### 3.3.3 Câncer de Pulmão (Respiratório)
Modelo Linear dependente do sexo:
*   Feminino: $ERR = 0.6 \cdot D$
*   Masculino: $ERR = 0.3 \cdot D$
Reflete a maior suscetibilidade relativa observada em mulheres no LSS (Life Span Study) para o mesmo nível de dose.

#### 3.3.4 Tireoide
Modelo Linear com limiar de idade:
*   Expostos < 18 anos: Risco muito elevado ($Coef \approx 7.5$).
*   Adultos: Risco reduzido ($Coef \approx 0.5$).

---

## 4. Métricas de Saída: ERR vs LAR

O sistema gera dois tipos de resultados distintos para garantir transparência científica.

### 4.1. Excesso de Risco Relativo (ERR)
Arquivo: `..._ERR.csv`
*   **Definição:** Aumento proporcional na taxa de incidência de câncer em relação à taxa basal da população.
*   *Exemplo:* ERR = 0.5 significa que o risco da pessoa exposta é 1.5 vezes o risco de uma pessoa não exposta.
*   **Unidade:** Adimensional.

### 4.2. Risco Atribuível ao Longo da Vida (LAR)
Arquivo: `..._LAR.csv`
*   **Definição:** A probabilidade absoluta (excesso) de que um indivíduo desenvolva câncer prematuramente devido à dose recebida.
*   **Método de Cálculo (Aproximação de 1ª Ordem):**
    $$LAR \approx ERR \times B_s(c)$$
    Onde $B_s(c)$ é a **Incidência Basal Vitalícia Estimada** para o câncer $c$ no sexo $s$.
*   **Fonte de Dados ($B_s$):** O sistema utiliza a projeção de incidência baseada na **Estimativa INCA 2023 (Brasil)**, convertendo as taxas anuais ajustadas (M/F) em risco acumulado para 75 anos de expectativa de vida.
    *   O cálculo respeita o dimorfismo sexual (ex: usa taxa basal de mama feminina para mulheres e masculina - insignificante - para homens).

---

## 5. Parâmetros de Entrada e Referência

Todos os coeficientes ($\beta, \gamma, \eta$, DDREF) são carregados dinamicamente do arquivo de controle `beirVII_hotspot_organ_equivalance_parameters.csv`. Isso permite:
1.  **Rastreabilidade:** Os parâmetros não estão "escondidos" (hardcoded) no código.
2.  **Atualização:** Novos estudos podem ser incorporados apenas atualizando o CSV, sem recompilar o software.

---

**Referências Bibliográficas:**
1.  National Research Council. (2006). *Health Risks from Exposure to Low Levels of Ionizing Radiation: BEIR VII Phase 2*. Washington, DC: The National Academies Press.
2.  National Research Council. (1990). *Health Effects of Exposure to Low Levels of Ionizing Radiation: BEIR V*. Washington, DC: The National Academies Press.
3.  Instituto Nacional de Câncer (INCA). (2022). *Estimativa 2023: incidência de câncer no Brasil*. Rio de Janeiro: INCA.
