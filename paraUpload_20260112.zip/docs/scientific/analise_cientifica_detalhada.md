# Relatório de Auditoria Científica e Metodológica: Sistema Dose2Risk

**Data:** 2025-12-11
**Objeto de Análise:** Consistência Científica (BEIR V e BEIR VII), Parâmetros e Equações.

---

## 1. Resumo da Auditoria

A análise revelou que a implementação do **BEIR VII (para baixas doses)** está metodologicamente correta em sua estrutura matemática.

No entanto, há uma **falha crítica** na implementação do **BEIR V (para altas doses)**. O código atual aplica os coeficientes específicos de **Leucemia** do BEIR V para **todos os órgãos**. Cientificamente, isso invalida os resultados para qualquer dose acima de 100 mSv, pois trata o risco de câncer no fígado, tireoide ou pulmão como se fossem leucemia.

Além disso, há uma ambiguidade na unidade de saída (Risco Relativo vs Risco Absoluto) que precisa ser esclarecida para o usuário final.

---

## 2. Análise Detalhada dos Modelos

### 2.1. Modelo BEIR VII (Doses < 100 mSv)
*   **Status: CORRETO E CONSISTENTE.**
*   **Equação Câncer Sólido:**
    $$ERR = \beta \cdot D \cdot \exp(\gamma \cdot e^*) \cdot (a/60)^\eta$$
    A implementação no código (`err = beta * D * math.exp(...) * pow(...)`) reflete exatamente a equação paramétrica do BEIR VII.
*   **Equação Leucemia:**
    A implementação inclui o termo linear-quadrático $(1 + \theta D)$ e os ajustes temporais corretos.
*   **Ajuste de Idade ($e^*$):**
    A lógica $(age\_exp - 30)/10$ para < 30 anos está conforme a definição do relatório.
*   **Parâmetros (CSV):**
    A estrutura de leitura do CSV permite que cada órgão tenha sua radiossensibilidade correta ($\beta_M, \beta_F$).

### 2.2. Modelo BEIR V (Doses >= 100 mSv)
*   **Status: METODOLOGICAMENTE INVÁLIDO (CRÍTICO).**
*   **O Erro Identificado:**
    Na função `beir_v_risk`, o código define coeficientes fixos (Hardcoded):
    ```python
    ALPHA2 = 0.243
    ALPHA3 = 0.271
    ```
    Estes valores ($0.243 D + 0.271 D^2$) correspondem especificamente ao modelo de **Leucemia** do relatório BEIR V (Tabela 4-2 do relatório original).
*   **O Problema Científico:**
    O código aplica esses coeficientes de leucemia para calcular o risco de **todos os outros órgãos** (Tireoide, Pulmão, Mama, etc.) sempre que a dose passa de 100 mSv.
    Isso é incorreto. No BEIR V, o risco de câncer de mama, por exemplo, segue um modelo linear de risco relativo com coeficientes totalmente diferentes, e o câncer respiratório usa outro modelo.
*   **Recomendação Imediata:**
    Não é possível sustentar cientificamente o uso desses coeficientes fixos para todos os órgãos. O código para BEIR V precisa ou (A) Receber parâmetros específicos via CSV (complexo, pois as equações do BEIR V variam entre órgãos) ou (B) Ser removido/substituído pela projeção linear do BEIR VII (com devidas ressalvas).

### 2.3. Unidade de Saída (Interpretação do Risco)
*   **Status: AMBÍGUO.**
*   **Análise:** O sistema calcula o **ERR (Excess Relative Risk)**.
    *   Exemplo: Um resultado de `0.2` significa "Aumento de 20% na taxa de incidência basal".
    *   **Não é** a probabilidade de ter câncer (LAR - Lifetime Attributable Risk).
*   **Omissão de Taxa Basal:**
    A função `beir_v_risk` tem um parâmetro `baseline_rate`, mas na chamada principal (loop do `calcular`), o valor passado é `None` (ou não é passado).
    Isso confirma que o software entrega Risco Relativo. Isso deve estar explícito na interface e nos relatórios, caso contrário, o usuário pode achar que `0.2` significa `20% de chance de ter câncer`, o que seria um erro de interpretação grave.

## 3. Análise da Dosimetria (Input do HotSpot)

*   **Dose Comprometida vs. Dose Aguda:**
    Os arquivos do HotSpot fornecem "Committed Dose" (Dose Comprometida em 50 anos) para inalação.
    *   O Sistema `Dose2Risk` pega esse valor total e o insere na equação como se a dose fosse recebida instantaneamente na `idade de exposição`.
    *   **Impacto Científico:** Para cânceres sólidos (latência longa), isso é uma aproximação aceitável (conservadora). Para Leucemia (latência curta de 2 anos), assumir que toda a dose de 50 anos foi recebida no "Dia 1" superestima drasticamente o risco da parcela inalada.
    *   **Recomendação:** Se mantiver assim, deve-se adicionar uma nota metodológica de que o cálculo assume "Dose Aguda Equivalente à Dose Comprometida", o que é uma abordagem de triagem conservadora.

## 4. Conclusão e Plano de Ação

1.  **Ação Crítica (BEIR V):** A implementação atual do BEIR V deve ser alterada. Como o modelo BEIR V varia a forma da equação por órgão (não apenas os parâmetros), implementá-lo corretamente exigiria reescrever todo o motor de cálculo. **Sugestão:** Utilizar o BEIR VII para todas as faixas (já que o LSS suporta altas doses) ou alertar que o fallback BEIR V atual é **apenas para Leucemia**.
2.  **Transparência:** Renomear as colunas de saída de `risk` para `ERR` (Excess Relative Risk) para evitar confusão com LAR.

O sistema é robusto em código, mas a generalização do BEIR V compromete a validade científica para altas doses em órgãos sólidos.
