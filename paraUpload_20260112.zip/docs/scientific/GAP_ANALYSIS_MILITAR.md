# Relatório de Análise de Discrepância (Gap Analysis) - Padrão Militar
**Data:** 17 de Dezembro de 2025
**Classificação:** Análise Técnica Profunda
**Status Atual:** Nível Acadêmico/Protótipo
**Status Alvo:** Nível Militar/Engenharia Crítica (Mission Critical)

---

## 1. Resumo Executivo

A aplicação **Dose2Risk**, embora funcional e cientificamente embasada (v2.0), apresenta um nível de maturidade de engenharia de software compatível com ambientes acadêmicos ou de desenvolvimento inicial. Para atingir "Padrões Militares" (robustez, auditabilidade, segurança e previsibilidade absoluta), foram identificadas lacunas críticas que impedem sua homologação em ambiente operacional real.

**Principais Gaps:**
1.  **Segurança da Informação:** Segredos expostos no código e servidor rodando em modo debug.
2.  **Garantia de Qualidade (QA):** Ausência total de testes unitários automatizados.
3.  **Infraestrutura:** Gerenciamento de dependências frágil e falta de containerização.
4.  **Arquitetura de Código:** Falta de tipagem estática e presença de rotas "mortas" ou código legado.

---

## 2. Detalhamento Técnico dos Gaps

### 2.1 Segurança (Crítico)
*   **Segredos Expostos (Hardcoded Secrets):**
    *   *Achado:* O arquivo `dose2risk/api/__init__.py` contém `app.secret_key = 'segredo_simples_para_flash'`.
    *   *Risco:* Comprometimento de sessões de usuário e vulnerabilidade a ataques CSRF/Session Hijacking.
    *   *Requisito Militar:* Segredos devem ser injetados via Variáveis de Ambiente (`os.getenv`) e nunca versionados no Git.
*   **Modo Debug Ativado:**
    *   *Achado:* O arquivo `run.py` executa com `app.run(debug=True)`.
    *   *Risco:* Exposição de stack traces detalhados e código fonte em caso de erro, além de permitir execução arbitrária de código via console do debugger Werkzeug em redes não confiáveis.
    *   *Requisito Militar:* Execução via servidor WSGI (Gunicorn/Uvicorn) com `debug=False` explícito.

### 2.2 Infraestrutura e Reprodutibilidade (Alto)
*   **Dependências Soltas (Loose Dependencies):**
    *   *Achado:* O `requirements.txt` lista pacotes sem versão (ex: `pandas`, `flask`).
    *   *Risco:* "Works on my machine". Uma atualização minoritária do Pandas ou Flask pode quebrar o sistema silenciosamente em produção.
    *   *Requisito Militar:* Pinar versões exatas (ex: `pandas==2.1.0`) e usar hashes SHA256 para garantir integridade da cadeia de suprimentos (Supply Chain Security).
*   **Falta de Containerização:**
    *   *Achado:* Não há `Dockerfile` ou `docker-compose.yml`.
    *   *Risco:* Dependência do ambiente do SO hospedeiro e dificuldade de escalabilidade/recuperação de desastre.
    *   *Requisito Militar:* Imagens Docker multi-stage build, rootless, com escaneamento de vulnerabilidades (Trivy/Snyk).

### 2.3 Garantia de Qualidade e Testes (Crítico)
*   **Ausência de Testes Automatizados:**
    *   *Achado:* A pasta `tests/` contém subpastas com datas (`20251217`) que parecem ser saídas de execução manual, e não scripts de teste (`test_xxx.py`) usando frameworks como `pytest` ou `unittest`.
    *   *Risco:* Regressão. Alterar uma lógica no `risk_calculator.py` pode quebrar casos de borda silenciosamente. Impossível garantir integridade após refatoração.
    *   *Requisito Militar:* Cobertura de testes > 85% (Code Coverage), incluindo testes unitários (lógica matemática), integração (pipeline) e E2E (API). Execução bloqueante no CI/CD.

### 2.4 Qualidade de Código e Manutenibilidade (Médio)
*   **Tipagem Dinâmica (Lack of Type Hints):**
    *   *Achado:* Métodos críticos (ex: `beir_v_risk`) não declaram tipos de entrada/saída.
    *   *Risco:* Erros de tipo (passar `str` onde se espera `float`) só são pegos em tempo de execução (Runtime), podendo causar falha de missão.
    *   *Requisito Militar:* Uso estrito de Type Hints (`def func(a: float) -> float:`) e validação estática via `mypy` no pipeline.
*   **Código Legado:**
    *   *Achado:* Existência de pasta `_legacy`.
    *   *Risco:* Confusão para novos desenvolvedores e potencial vetor de ataque se arquivos forem importados acidentalmente.
    *   *Requisito Militar:* Limpeza total de artefatos não utilizados. Histórico deve ficar no Git, não no sistema de arquivos.

---

## 3. Plano de Ação Recomendado (Roadmap)

Para elevar o Dose2Risk ao nível de exigência solicitado, recomenda-se a seguinte ordem de execução:

### Fase 1: Blindagem (Imediato)
1.  [ ] **Externalizar Configuração:** Criar `.env` e usar `python-dotenv` para carregar `SECRET_KEY` e caminhos.
2.  [ ] **Dockerizar:** Criar `Dockerfile` robusto para garantir que o ambiente de execução seja imutável.
3.  [ ] **Lock de Dependências:** Gerar `requirements.lock` ou usar `poetry` para travar versões.

### Fase 2: Garantia (Curto Prazo)
4.  [ ] **Implementar Testes Unitários:** Criar suíte `pytest` cobrindo 100% das funções matemáticas do BEIR V e VII (Testar contra valores conhecidos).
5.  [ ] **CI/CD Básico:** Criar workflow (GitHub Actions ou GitLab CI) que roda os testes a cada push.

### Fase 3: Refinamento (Médio Prazo)
6.  [ ] **Type Hinting:** Adicionar anotações de tipo em todo o `core` e rodar `mypy --strict`.
7.  [ ] **Limpeza:** Remover `_legacy` e arquivos temporários.

---

## 4. Conclusão

O software possui um núcleo matemático sólido (agora na v2.0), mas sua "casca" de engenharia é frágil. Para fins de auditoria acadêmica rigorosa ou uso oficial, a implementação da **Fase 1** e **Fase 2** é mandatória. Sem isso, o software não passa em critérios básicos de engenharia de sistemas críticos.
