# RELATÓRIO DE ANÁLISE DE GAP
## Tese de Doutorado: Dose2Risk - Instituto Militar de Engenharia

**Data:** 02 de Janeiro de 2026  
**Escopo:** Comparação entre Proposta de Qualificação e Manuscrito Atual

---

## 1. RESUMO EXECUTIVO

Após análise minuciosa da Proposta de Qualificação aprovada (Agosto/2025) e dos cinco capítulos do manuscrito atual, foram identificadas **lacunas significativas** que podem gerar questionamentos pela banca examinadora. Este relatório classifica as lacunas por criticidade e oferece recomendações de ação.

> [!CAUTION]
> Há GAPs críticos que comprometem promessas centrais da qualificação. A banca do IME pode questionar diretamente esses pontos.

---

## 2. CLASSIFICAÇÃO DAS LACUNAS

| Nível | Descrição | Qtd. |
|:---:|:---|:---:|
| 🔴 | **CRÍTICO** - Promessa não atendida ou ausente | 4 |
| 🟠 | **MODERADO** - Incompleto ou superficial | 5 |
| 🟡 | **MENOR** - Detalhes desejáveis ausentes | 3 |

---

## 3. ANÁLISE DETALHADA

### 🔴 LACUNAS CRÍTICAS

#### 3.1. Estudos de Caso Incompletos
**Prometido na Qualificação (Seção 1.3.2 - Objetivo 6):**
> "Demonstrar a aplicabilidade prática do sistema desenvolvido por meio de estudos de caso representativos em diferentes cenários de proteção radiológica: (i) simulação de resposta a um acidente radiológico em área urbana, (ii) avaliação de impacto radiológico em instalação nuclear e (iii) análise radioepidemiológica de exposição ocupacional."

**Situação no Manuscrito:**
- ✅ Estudo de Caso 1 (RDD urbano): Presente no Capítulo 4
- ❌ **Estudo de Caso 2 (Acidente em Instalação Nuclear)**: AUSENTE
- ❌ **Estudo de Caso 3 (Exposição Ocupacional)**: AUSENTE

**Risco:** A banca pode questionar por que apenas 1 dos 3 estudos de caso prometidos foi apresentado.

**Ação Recomendada:** Adicionar seções 4.3 e 4.4 com os estudos de caso faltantes.

---

#### 3.2. Interface Multilíngue Não Demonstrada
**Prometido na Qualificação (Seção 1.3.2 - Objetivo 4):**
> "Criar uma interface web responsiva e multilíngue (português, inglês, francês e espanhol)..."

**Situação no Manuscrito:**
- ❌ A funcionalidade multilíngue não é mencionada em nenhum capítulo.

**Risco:** Essa foi uma promessa explícita e específica. Ausência pode indicar descumprimento de objetivo.

**Ação Recomendada:** Adicionar texto no Capítulo 3 descrevendo a implementação i18n (internacionalização) ou justificar a limitação como trabalho futuro.

---

#### 3.3. Validação Quantitativa Ausente
**Prometido na Qualificação (Seção 5.2):**
> "Redução do tempo de processamento de cenários de risco radiológico de aproximadamente duas horas para menos de dois minutos, representando melhoria de eficiência superior a 98%."
> "Precisão matemática consistente com tolerâncias inferiores a 0.1%."

**Situação no Manuscrito:**
- ❌ O Capítulo 4 menciona "de horas para segundos" de forma genérica, sem dados quantitativos.
- ❌ Não há tabela comparativa mostrando tempo manual vs. automatizado.
- ❌ Não há demonstração da tolerância de erro.

**Risco:** Sem dados numéricos, a banca pode questionar a validade das afirmações de eficiência.

**Ação Recomendada:** Incluir:
1. Tabela com tempos de execução medidos (em segundos).
2. Comparação numérica com cálculo manual de referência.
3. Gráficos de dispersão de erro.

---

#### 3.4. Protocolo de Testes Superficial
**Prometido na Qualificação (Seção 3.4 - Fase 4):**
> Protocolo abrangente incluindo:
> - Testes unitários (PyTest)
> - Testes de integração
> - Testes de sistema com Selenium
> - Testes de estresse e robustez
> - GitHub Actions para CI

**Situação no Manuscrito:**
- O Capítulo 3 (Seção 3.5) descreve validação de forma breve (apenas 4 linhas).
- ❌ Não há menção a PyTest, Selenium, GitHub Actions, ou cobertura de código.

**Risco:** A qualificação prometeu rigor de TDD; o manuscrito atual não demonstra essa profundidade.

**Ação Recomendada:** Expandir Seção 3.5 detalhando os casos de teste implementados, métricas de cobertura e ferramentas utilizadas.

---

### 🟠 LACUNAS MODERADAS

#### 3.5. Tabela de Arquivos de Saída Ausente
**Prometido na Qualificação (TAB 3):**
> Descrição detalhada dos 4 arquivos gerados pelo pipeline:
> 1. `1_hotspot_extract_...csv`
> 2. `2_hotspot_transpose_...csv`
> 3. `3_calculated_risks_...csv`
> 4. `4_execution_log_...log`

**Situação:** Mencionado brevemente no Cap. 2 e 3, mas sem a tabela formal.

**Ação:** Inserir tabela equivalente à TAB 3 da qualificação no Capítulo 3.

---

#### 3.6. Padrões de Projeto Não Documentados
**Prometido:** Uso de Strategy e Factory patterns para seleção dinâmica de modelos BEIR.

**Situação:** O manuscrito descreve a lógica híbrida, mas não nomeia os padrões de projeto.

**Ação:** Mencionar explicitamente os padrões no Cap. 3 para demonstrar rigor de engenharia de software.

---

#### 3.7. Mapeamento Anatômico Incompleto
**Prometido (TAB 2 da Qualificação):**
> Tabela completa de equivalência entre órgãos HotSpot e categorias BEIR, com coeficientes β, γ, η.

**Situação:** O Cap. 2 menciona o mapeamento, mas não inclui a tabela completa de coeficientes.

**Ação:** Adicionar tabela com pelo menos os 10 órgãos principais e seus parâmetros.

---

#### 3.8. Fontes das Equações sem Páginas Específicas
**Problema:** As equações BEIR estão citadas com referência genérica "[3], [4]".

**Padrão para Teses:** Referências a equações devem incluir página/tabela específica do relatório original.

**Ação:** Revisar Cap. 2 incluindo citações como "BEIR VII, Tabela 12-2, p. 278".

---

#### 3.9. Cronograma e Publicações Não Mencionados
**Prometido:** 3 artigos científicos, workshops, patente.

**Situação:** O Cap. 5 não menciona publicações realizadas ou planejadas.

**Ação:** Incluir seção sobre disseminação científica nas Considerações Finais.

---

### 🟡 LACUNAS MENORES

#### 3.10. Acessibilidade (WCAG 2.1)
**Prometido:** Conformidade com diretrizes de acessibilidade web.

**Ação:** Inserir parágrafo no Cap. 3 sobre práticas de acessibilidade adotadas.

---

#### 3.11. Modo Noturno (Dark Mode)
**Prometido:** Funcionalidade de tema escuro.

**Ação:** Mencionar nas funcionalidades da interface ou mover para Trabalhos Futuros.

---

#### 3.12. Revisão de Literatura (Estado da Arte)
**Prometido na Qualificação (Seção 1.1):**
> Revisão incluindo Apostoaei et al., IAEA GSG-2, Wilson et al., Sandve et al., Grüning et al.

**Situação:** O Cap. 2 não tem seção formal de "Estado da Arte" comparando com outras ferramentas (ex: RESRAD-RDD).

**Ação:** Adicionar subseção 2.5 "Estado da Arte e Ferramentas Correlatas".

---

## 4. MATRIZ DE AÇÕES PRIORITÁRIAS

| Prioridade | Ação | Capítulo | Esforço |
|:---:|:---|:---:|:---:|
| 1 | Adicionar Estudo de Caso 2 (Usina Nuclear) | Cap. 4 | Alto |
| 2 | Adicionar Estudo de Caso 3 (Ocupacional) | Cap. 4 | Alto |
| 3 | Inserir dados quantitativos de validação | Cap. 4 | Médio |
| 4 | Expandir seção de Testes e Validação | Cap. 3 | Médio |
| 5 | Adicionar tabela de mapeamento anatômico | Cap. 2 | Baixo |
| 6 | Detalhar interface multilíngue ou justificar | Cap. 3 | Baixo |
| 7 | Adicionar tabela de arquivos de saída | Cap. 3 | Baixo |
| 8 | Revisar citações com páginas específicas | Cap. 2 | Baixo |
| 9 | Adicionar seção Estado da Arte | Cap. 2 | Médio |
| 10 | Mencionar publicações e disseminação | Cap. 5 | Baixo |

---

## 5. CONCLUSÃO DA ANÁLISE

O manuscrito atual apresenta uma base sólida, porém incompleta em relação aos compromissos assumidos na qualificação. Os **pontos críticos** (Estudos de Caso faltantes e Validação Quantitativa) devem ser priorizados, pois são promessas explícitas que a banca certamente verificará.

Recomenda-se que o doutorando dedique as próximas sessões de trabalho à:
1. Execução e documentação dos 2 estudos de caso faltantes.
2. Coleta de métricas de tempo e precisão para validação quantitativa.
3. Revisão granular das referências bibliográficas.

---

*Relatório gerado por análise automatizada em 02/01/2026.*
