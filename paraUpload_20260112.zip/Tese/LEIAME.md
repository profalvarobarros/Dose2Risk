# Estrutura da Tese - Dose2Risk

Este diretório contém toda a organização da Tese de Doutorado. A estrutura foi pensada para separar o texto principal, documentos de suporte e produção derivada.

## Estrutura de Diretórios

### 📁 Manuscrito
Local destinado ao texto da tese propriamente dito.
- Deve conter os arquivos .tex, .md ou .docx dos capítulos.
- Versões incrementais do texto.

### 📁 Documentos_Apoio
Local para armazenar materiais que fundamentam a tese, mas não fazem parte do texto principal.
- Documentos da Qualificação.
- Referências bibliográficas (PDFs).
- Notas de aula ou reuniões.

### 📁 Artigos
Diretório exclusivo para a produção de artigos científicos derivados da tese.
- Rascunhos de papers.
- Submissões para congressos/periódicos (pastas por evento).

### 📁 Formatos_Modelos
Repositório de templates e padrões.
- Modelos de Tese do IME/USP.
- Exemplos de formatação.
- Logos e imagens institucionais.
