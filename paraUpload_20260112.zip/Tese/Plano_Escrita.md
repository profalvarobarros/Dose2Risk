# Plano de Escrita da Tese - Dose2Risk

Este documento define a estrutura proposta para a Tese de Doutorado, baseada na Qualificação aprovada ("Integração Automatizada de Modelos de Risco Radiológico para Avaliação de Impacto em Políticas de Defesa").

## Estrutura de Capítulos Proposta

A seguir, a estrutura sugerida para a organização do manuscrito da tese.

### 1. Introdução
*Baseado na Seção 1 da Qualificação.*
- Contextualização (Proteção Radiológica, HotSpot, BEIR).
- Definição do Problema (Lacuna de interoperabilidade, ineficiência manual).
- Objetivos (Geral e Específicos).
- Justificativa (Científica, Defesa Nacional, Inovação).
- Estrutura do Trabalho.

### 2. Fundamentação Teórica
*Baseado na Seção 2 da Qualificação, expandido.*
- 2.1 Modelagem de Dispersão Atmosférica (Física, Modelo Gaussiano, HotSpot).
- 2.2 Modelos Radioepidemiológicos (BEIR V e VII, coeficientes de risco, equações).
- 2.3 Engenharia de Software Científico (Arquitetura Modular, TDD, Usabilidade, Reprodutibilidade).
- 2.4 Estado da Arte (Revisão sistemática atualizada).

### 3. Metodologia e Desenvolvimento
*Evolução da Seção 3 da Qualificação.*
- 3.1 Arquitetura do Sistema Dose2Risk.
- 3.2 Módulos de Extração e Tratamento de Dados (HotSpot Extract).
- 3.3 Implementação dos Modelos de Risco (Risk Calculator).
- 3.4 Interface e Experiência do Usuário (Frontend/Backend).
- 3.5 Processo de Validação e Verificação (Testes Unitários, Integração).

### 4. Resultados e Discussão (Estudos de Caso)
*Transformação da Seção 5 da Qualificação em Resultados Reais.*
- 4.1 Validação Técnica (Performance, Precisão Numérica vs Manual).
- 4.2 Estudo de Caso 1: Evento RDD ("Bomba Suja") em Área Urbana.
  - Análise dos mapas de risco gerados.
  - Comparação com métodos tradicionais.
- 4.3 Estudo de Caso 2: Acidente em Usina Nuclear.
- 4.4 Estudo de Caso 3: Exposição Ocupacional.
- 4.5 Discussão Geral (Impacto nas políticas de defesa e resposta).

### 5. Conclusões e Trabalhos Futuros
*Baseado na Seção 6 da Qualificação.*
- Retomada dos objetivos alcançados.
- Contribuições originais (Sistema, Base de Dados, Metodologia).
- Limitações do estudo.
- Recomendações para trabalhos futuros.

### Apêndices e Anexos
- Código-fonte principal (links ou trechos).
- Manual do Usuário do Dose2Risk.
- Tabelas de Coeficientes Utilizadas.

## Cronograma de Escrita (Estimativa)

| Etapa | Atividade | Prazo Sugerido | Status |
| :--- | :--- | :--- | :--- |
| **Fase 1** | Estruturação e Revisão da Teoria (Cap 2) | TBD | [ ] |
| **Fase 2** | Detalhamento da Metodologia Implementada (Cap 3) | TBD | [ ] |
| **Fase 3** | Execução e Escrita dos Estudos de Caso (Cap 4) | TBD | [ ] |
| **Fase 4** | Introdução e Conclusão | TBD | [ ] |
| **Fase 5** | Revisão Geral e Formatação | TBD | [ ] |

## Ações Imediatas
1.  Validar esta estrutura de capítulos.
2.  Definir prazos para o Cronograma.
3.  Migrar conteúdo reaproveitável da Qualificação para os respectivos capítulos na pasta `Manuscrito`.
