# CAPÍTULO 2
# FUNDAMENTAÇÃO TEÓRICA

Este capítulo apresenta os pilares científicos e tecnológicos que sustentam o desenvolvimento do sistema Dose2Risk. A fundamentação divide-se em três eixos principais: a modelagem física da dispersão atmosférica, os modelos radioepidemiológicos de risco de câncer e os princípios de arquitetura de software aplicados.

## 2.1. Modelagem de Dispersão Atmosférica e o Código HotSpot

A avaliação de consequências em incidentes radiológicos inicia-se pela estimativa de qual dose de radiação os indivíduos expostos receberão. Para liberações atmosféricas, isso exige a modelagem do transporte, difusão e deposição de radionuclídeos.

O código **HotSpot Health Physics Code**, desenvolvido pelo *Lawrence Livermore National Laboratory* (LLNL), utiliza um modelo de pluma Gaussiana para estimar a concentração de contaminantes na linha central da pluma. A equação básica de difusão Gaussiana utilizada é dada por:

$$ C(x,y,z) = \frac{Q}{2\pi \sigma_y \sigma_z u} \exp\left[ -\frac{1}{2} \left( \frac{y}{\sigma_y} \right)^2 \right] \left\{ \exp\left[ -\frac{1}{2} \left( \frac{z-H}{\sigma_z} \right)^2 \right] + \exp\left[ -\frac{1}{2} \left( \frac{z+H}{\sigma_z} \right)^2 \right] \right\} $$

Onde:
*   $C$: Concentração integrada no tempo ($Ci \cdot s/m^3$).
*   $Q$: Termo fonte (Atividade liberada).
*   $u$: Velocidade média do vento ($m/s$).
*   $\sigma_y, \sigma_z$: Desvios padrão da distribuição de concentração (função da estabilidade atmosférica e distância $x$).
*   $H$: Altura efetiva de liberação.

O Dose2Risk utiliza os arquivos de saída do HotSpot como dados de entrada primários, aceitando estimativas de *Total Effective Dose Equivalent* (TEDE) e doses órgão-específicas calculadas pelo software para diferentes classes de estabilidade de Pasquill (A-F).

## 2.2. Modelos Radioepidemiológicos (BEIR)

Para traduzir a dose absorvida em probabilidade de efeitos estocásticos (câncer), utilizam-se os modelos desenvolvidos pelo comitê *Biological Effects of Ionizing Radiation* (BEIR) do *National Research Council* dos EUA. O sistema implementa uma abordagem **híbrida**, selecionando dinamicamente o modelo mais adequado conforme a magnitude da dose.

### 2.2.1. Critério de Decisão Híbrido

O sistema avalia a dose absorvida ($D$) em cada célula da matriz de cálculo (combinação de órgão e cenário) e aplica a seguinte lógica de seleção:

$$
\text{Modelo}(D) =
\begin{cases}
\text{BEIR VII (Fase 2)} & \text{se } D < 100 \text{ mSv} \\
\text{BEIR V (1990)} & \text{se } D \ge 100 \text{ mSv}
\end{cases}
$$

Este limiar de 100 mSv (0.1 Sv) é justificado pela literatura [1, 4], onde o modelo BEIR VII é otimizado para baixas doses (regime linear), enquanto o BEIR V oferece melhor ajuste para doses elevadas, capturando efeitos não-lineares observados em sobreviventes de bombas atômicas.

### 2.2.2. Modelo BEIR VII (Baixas Doses)

Para o regime de baixas doses, o risco é estimado pelo *Excess Relative Risk* (ERR). Para cânceres sólidos, a equação geral implementada é:

$$ ERR = \beta_s \cdot D \cdot \exp(\gamma \cdot e^*) \cdot \left(\frac{a}{60}\right)^\eta \cdot \frac{1}{\text{DDREF}} $$

Onde:
*   $\beta_s$: Coeficiente de risco dependente do sexo.
*   $D$: Dose absorvida (Sv).
*   $e^*$: Idade efetiva na exposição (ajustada para penalizar exposições na infância).
*   $a$: Idade atingida (*attained age*).
*   $\eta$: Parâmetro de decaimento do risco com o envelhecimento.
*   **DDREF** (*Dose and Dose-Rate Effectiveness Factor*): Fator de redução de risco para baixas doses (padrão 1.5).

Para **Leucemia**, o modelo adota uma forma linear-quadrática:

$$ ERR = \beta_s D (1 + \theta D) \cdot \exp(\gamma e^* + \delta \ln(t/25) + \phi e^* \ln(t/25)) $$

Onde:
*   $\beta_s$: Coeficiente linear de risco dependente do sexo.
*   $D$: Dose absorvida (Sv).
*   $\theta$: Parâmetro de curvatura que define o componente quadrático da resposta à dose.
*   $\gamma$: Coeficiente de modificação pela idade na exposição.
*   $e^*$: Idade efetiva na exposição (ajustada).
*   $\delta$: Coeficiente de modificação pelo tempo decorrido desde a exposição.
*   $t$: Tempo decorrido desde a exposição (anos).
*   $\phi$: Termo de interação entre a idade na exposição e o tempo decorrido.

### 2.2.3. Modelo BEIR V (Altas Doses)

No regime de altas doses, o sistema utiliza as formulações do relatório de 1990. Para a maioria dos cânceres sólidos (ex: respiratórios, digestivos), utiliza-se um modelo linear direto:

$$ ERR = C_{\text{sexo}} \cdot D $$

Onde:
*   $C_{\text{sexo}}$: Coeficiente linear de risco específico para o sexo (derivado das tabelas do BEIR V).
*   $D$: Dose absorvida (Sv).

Para **Leucemia** em altas doses, retoma-se o modelo linear-quadrático, modulado por janelas temporais desde a exposição:

$$ ERR = (\alpha_1 D + \alpha_2 D^2) \cdot \exp(\beta_{tempo}) $$

Onde:
*   $\alpha_1, \alpha_2$: Coeficientes para os termos linear e quadrático da dose, respectivamente.
*   $D$: Dose absorvida (Sv).
*   $\beta_{tempo}$: Fator de modificação temporal, cujos valores variam conforme janelas discretas de tempo decorrido desde a exposição (ex: < 15 anos, > 15 anos).

## 2.3. Arquitetura do Sistema Dose2Risk

A arquitetura do Dose2Risk foi projetada para garantir **rastreabilidade**, **auditabilidade** e **eficiência**. O sistema opera como um pipeline de dados sequencial (ETL - *Extract, Transform, Load/Calculate*).

### 2.3.1. Fluxo de Dados Macro

O diagrama a seguir ilustra o fluxo de dados desde a ingestão dos arquivos do HotSpot até a geração dos relatórios de risco.

```mermaid
graph TD
    A[Arquivos HotSpot (.txt)] -->|Extração| B(Extrator: Parse Estruturado)
    B -->|Normalização| C[CSV Tabular Intermediário]
    C -->|Transposição| D(Transpositor: Pivotagem)
    D -->|Matriz Órgão x Cenário| E[CSV Transposto]
    E -->|Cálculo| F{Calculadora de Risco}
    G[Parâmetros BEIR] --> F
    F -->|Dose < 100 mSv| H[Modelo BEIR VII]
    F -->|Dose >= 100 mSv| I[Modelo BEIR V]
    H --> J[Saída: Arquivos .csv e Log]
    I --> J
```

### 2.3.2. Componentes da Arquitetura

1.  **Camada de Extração (Input Layer)**: Responsável por ler os arquivos de texto não estruturados gerados pelo HotSpot. Utiliza expressões regulares (Regex) para identificar e extrair tabelas de dose e metadados da simulação.
2.  **Camada de Transformação**: Realiza a limpeza e normalização dos dados. Uma função crítica é a **transposição**, que converte a lista vertical de doses do HotSpot em uma matriz *Órgão x Cenário*, facilitando operações vetoriais.
3.  **Camada de Cálculo (Calculation Layer)**: O "coração" do sistema. Implementa as equações descritas na Seção 2.2, aplicando os fatores de risco apropriados para cada órgão mapeado.
4.  **Camada de Saída (Output Layer)**: Gera os artefatos finais, incluindo bases de dados em CSV (`_ERR.csv`, `_LAR.csv`) e, crucialmente, um arquivo de **Log de Auditoria** que registra qual equação e parâmetros foram usados para cada cálculo individual.

## 2.4. Engenharia de Software Científico

O desenvolvimento seguiu práticas modernas de engenharia de software para garantir a confiabilidade dos resultados:
*   **Testes Automatizados (TDD)**: Uso de testes unitários para validar matematicamente cada função de risco contra valores de referência conhecidos.
*   **Parâmetros em Arquivos de Configuração**: Todos os coeficientes dos modelos BEIR (§, ®, etc.) são armazenados em arquivos JSON externos, permitindo atualização dos modelos sem alteração no código-fonte.
*   **Reprodutibilidade**: O sistema garante que, dados os mesmos arquivos de entrada e configuração, os resultados serão bit-a-bit idênticos, uma exigência para auditoria científica.

---

**Referências do Capítulo:**
[1] NRC. BEIR VII Phase 2. 2006.
[2] LLNL. HotSpot User's Guide. 2013.
[3] NRC. BEIR V. 1990.
[4] EPA. Radiogenic Cancer Risk Models. 2011.
