# CAPÍTULO 5
# CONCLUSÕES E TRABALHOS FUTUROS

A presente tese abordou o desafio de integrar ferramentas de modelagem de dispersão atmosférica e modelos radioepidemiológicos, visando otimizar a avaliação de riscos em cenários de emergência radiológica. O desenvolvimento e validação do sistema **Dose2Risk** demonstraram a viabilidade técnica e os benefícios operacionais de uma abordagem automatizada e auditável.

## 5.1. Síntese dos Resultados

O objetivo principal de desenvolver um sistema computacional capaz de converter estimativas de dose do HotSpot em probabilidades de risco de câncer, utilizando os modelos BEIR V e VII, foi plenamente atingido. Os objetivos específicos também foram alcançados:

1.  **Arquitetura Implementada**: A arquitetura modular em Python provou-se robusta e extensível, permitindo a separação clara entre as camadas de extração, transformação e cálculo.
2.  **Automação Eficiente**: O sistema reduziu o tempo de análise de cenários complexos de horas para segundos, eliminando o gargalo operacional da transcrição manual.
3.  **Precisão e Conformidade**: A implementação do critério híbrido de seleção de modelos (BEIR VII < 100 mSv <= BEIR V) garantiu que as estimativas de risco respeitassem as melhores práticas científicas para diferentes regimes de dose.

## 5.2. Contribuições Originais

As principais contribuições desta pesquisa para a Engenharia de Defesa e a Proteção Radiológica incluem:

1.  **Metodologia Híbrida Automatizada**: A formalização computacional da transição entre modelos BEIR V e VII baseada em limiar de dose, implementada de forma transparente e auditável.
2.  **Arquitetura *Data-Driven***: O desacoplamento dos parâmetros matemáticos (JSON) do código-fonte (Python), permitindo que instituições atualizem os coeficientes de risco sem necessidade de reprogramação do sistema.
3.  **Rastreabilidade Cruzada**: O mecanismo de logs de auditoria vinculados aos resultados, estabelecendo um padrão para transparência em softwares de avaliação de risco.

## 5.3. Limitações do Estudo

A principal limitação identificada refere-se à natureza da dose de entrada. O sistema utiliza a *Committed Dose Equivalent* (CDE) de 50 anos como uma "dose aguda" para o cálculo de risco. Embora conservadora e segura para fins de proteção radiológica (princípio ALARA), essa abordagem pode superestimar o risco de leucemia em exposições envolvendo radionuclídeos de longa retenção biológica, visto que a dose real seria entregue ao longo de décadas, e não instantaneamente.

## 5.4. Disseminação e Produção Científica

Os resultados deste trabalho foram disseminados através das seguintes produções:

1.  **Artigos em Periódicos**: Preparação e submissão de artigo para o *Journal of Radiological Protection* (título provisório: "Automated Hybrid Risk Assessment System for RDD Scenarios").
2.  **Conferências**: Apresentação de trabalho no *International Congress of the IRPA* (International Radiation Protection Association).
3.  **Propriedade Intelectual**: Os algoritmos de integração e o mecanismo de rastreabilidade híbrida foram documentados para submissão de registro de software junto ao INPI.

## 5.5. Recomendações para Trabalhos Futuros

Com base nos resultados obtidos e nas fronteiras identificadas, sugerem-se as seguintes linhas de pesquisa para continuidade:

1.  **Integração com Sensores em Tempo Real**: Expandir o módulo de entrada para aceitar dados telemétricos de redes de monitoramento radiológico, permitindo avaliação de risco dinâmica durante a evolução de uma pluma.
2.  **Refinamento do Modelo Temporal**: Implementar algoritmos que distribuam a Dose Comprometida ao longo do tempo, permitindo um cálculo mais refinado de risco para leucemia (que possui janela de latência curta).
3.  **Módulo de Otimização de Decisão**: Incorporar algoritmos de pesquisa operacional para sugerir rotas de evacuação ou estratégias de abrigagem baseadas na minimização do *Lifetime Attributable Risk* (LAR) coletivo.

O Dose2Risk consolida-se, portanto, como uma ferramenta estratégica para a defesa nacional e a segurança nuclear, preenchendo uma lacuna tecnológica importante e abrindo caminhos para uma proteção radiológica mais ágil, precisa e baseada em evidências.
