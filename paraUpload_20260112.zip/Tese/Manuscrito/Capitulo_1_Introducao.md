# CAPÍTULO 1
# INTRODUÇÃO

## 1.1. Contextualização

A proteção radiológica constitui disciplina científica fundamental que integra conhecimentos de física das radiações, biologia molecular, epidemiologia e engenharia de sistemas, desenvolvendo metodologias rigorosas para avaliação e mitigação de riscos associados à exposição à radiação ionizante. No contexto contemporâneo, a necessidade de ferramentas computacionais eficientes e precisas para avaliação de risco radiológico tornou-se imperativa, especialmente considerando a crescente complexidade dos cenários de exposição e a demanda por respostas rápidas em situações de emergência nuclear.

Conforme diretrizes da *International Commission on Radiological Protection* (ICRP), a quantificação probabilística de riscos sanitários deve fundamentar as estratégias de proteção radiológica e o planejamento de contingências [1]. Essa abordagem quantitativa requer integração eficiente entre códigos de modelagem de dispersão atmosférica, que estimam distribuições espaciais de dose, e modelos radioepidemiológicos que convertem essas doses em probabilidades de efeitos biológicos adversos [1].

O código HotSpot, desenvolvido pelo *Lawrence Livermore National Laboratory* (LLNL), é uma referência amplamente utilizada para simulações rápidas de dispersão de materiais radioativos na atmosfera, fornecendo mapas detalhados de *Total Effective Dose Equivalent* (TEDE) e doses comprometidas a órgãos específicos [2]. Paralelamente, os relatórios BEIR V (1990) [3] e BEIR VII (2006) [4] do *National Research Council* estabeleceram modelos radioepidemiológicos validados que convertem dose absorvida em excesso de risco de desenvolvimento de câncer (*Excess Relative Risk* - ERR, ou risco absoluto), considerando fatores como idade, sexo e tipo de neoplasia.

Apesar de complementares, estas ferramentas historicamente carecem de interoperabilidade nativa. Profissionais frequentemente precisam transpor manualmente milhares de valores de dose do HotSpot para planilhas ou scripts *ad-hoc* que aplicam as fórmulas dos modelos BEIR, um processo laborioso e suscetível a erros humanos.

## 1.2. Definição do Problema

O problema central abordado nesta tese reside na ausência de ferramentas computacionais integradas que convertam automaticamente estimativas de dose do código HotSpot em probabilidades de desenvolvimento de câncer baseadas nos modelos BEIR. Essa lacuna resulta em limitações operacionais significativas que podem comprometer a efetividade e confiabilidade de avaliações de risco radiológico, especialmente em eventos de massa ou emergências.

Estudos preliminares e validações operacionais conduzidas no âmbito desta pesquisa identificaram que o processo manual de integração consome aproximadamente duas horas por cenário analisado e pode introduzir erros de cálculo superiores a 5% [6]. Os principais problemas específicos decorrentes dessa falta de automatização incluem:

1.  **Ineficácia temporal**: A transcrição manual limita drasticamente a capacidade de analisar múltiplos cenários em tempo hábil.
2.  **Suscetibilidade a erros sistemáticos**: A intervenção manual em cálculos complexos aumenta o risco de inconsistências.
3.  **Acesso restrito**: A complexidade das ferramentas originais restringe seu uso a um pequeno grupo de especialistas.
4.  **Rastreabilidade limitada**: Métodos manuais dificultam a auditoria e reprodução exata dos cálculos realizados.

## 1.3. Objetivos

### 1.3.1. Objetivo Geral

Desenvolver e validar um sistema computacional automatizado, denominado **Dose2Risk**, que integre simulações de dispersão atmosférica geradas pelo código HotSpot aos modelos radioepidemiológicos BEIR V e VII, produzindo bases de dados estruturadas de risco de câncer por radiação ionizante com rastreabilidade completa e interface acessível.

### 1.3.2. Objetivos Específicos

1.  **Arquitetura Modular**: Projetar uma arquitetura de software em Python que viabilize a integração eficiente e extensível entre os dados de saída do HotSpot e os algoritmos BEIR.
2.  **Extração Automatizada**: Desenvolver algoritmos para extração robusta de dados dos arquivos de saída do HotSpot, garantindo integridade das informações de dose.
3.  **Cálculo de Risco**: Implementar computacionalmente as formulações completas dos modelos BEIR V e VII, incorporando fatores de correção demográficos (idade, sexo) e tipologia de câncer.
4.  **Interface de Usuário**: Criar uma interface web intuitiva e multilíngue para democratizar o acesso à ferramenta.
5.  **Validação o Sistema**: Estabelecer protocolos de testes automatizados e estudos de caso para validar a precisão numérica e o ganho de desempenho operacional em relação aos métodos tradicionais.

## 1.4. Justificativa

A justificativa para esta pesquisa fundamenta-se em três pilares principais:

**Relevância Científica e Tecnológica**: A automatização de fluxos de trabalho científicos (*scientific workflows*) é uma tendência vital para garantir reprodutibilidade e transparência [8]. A integração HotSpot-BEIR preenche uma lacuna metodológica, permitindo que pesquisadores realizem estudos paramétricos em larga escala e gerem bases de dados estruturadas para análises epidemiológicas.

**Ineditismo da Pesquisa**: Para comprovar a originalidade da proposta, foram conduzidas buscas sistemáticas nas bases PUBMED e LILACS/BCI utilizando palavras-chave centrais do projeto e suas combinações booleanas. A Tabela 1 apresenta o volume de resultados encontrados, demonstrando o drástico decaimento na quantidade de publicações à medida que se combinam os termos, evidenciando a escassez de estudos que abordem simultaneamente a proteção radiológica, automação e os modelos BEIR.

**Tabela 1** - Comparação entre as bases PubMed e LILACS/BCI quanto ao número de resultados por palavras-chave e suas combinações.

| ID | Query de Busca | PubMed | LILACS/BCI | Total |
| :---: | :--- | :---: | :---: | :---: |
| A | `database` | 954.625 | 12.647 | 967.272 |
| B | `automation` | 299.813 | 427 | 300.240 |
| C | `automation` AND `database` | 22.038 | 29 | 22.067 |
| D | `radiological protection` | 3.974 | 94 | 4.068 |
| E | `BEIR VII` | 157 | 1 | 158 |
| F | `radiological protection` AND `database` | 123 | 2 | 125 |
| G | `BEIR V` | 34 | 0 | 34 |
| H | `radiocarcinogenesis` | 23 | 0 | 23 |
| I | `BEIR VII` AND `database` | 11 | 0 | 11 |
| J | `radiological protection` AND `BEIR VII` | 9 | 1 | 10 |
| K | `radiological protection` AND `automation` | 6 | 0 | 6 |
| L | `BEIR V` AND `BEIR VII` | 4 | 0 | 4 |
| M | `radiological protection` AND `BEIR V` | 2 | 0 | 2 |
| N | `radiological protection` AND `radiocarcinogenesis` | 1 | 0 | 1 |
| O | `automation` AND `BEIR VII` | 1 | 0 | 1 |
| P | `HotSpot Code` | 0 | 0 | 0 |

*Fonte: O Autor (2025).*

**Defesa Nacional e Resposta a Emergências**: No contexto da Engenharia de Defesa, a capacidade de avaliar riscos radiológicos rapidamente é estratégica. O sistema proposto fortalece a capacidade de resposta a incidentes envolvendo Dispositivos de Dispersão Radiológica (RDD) ou acidentes em instalações nucleares, fornecendo dados críticos para tomada de decisão em tempo real [5].

**Impacto Social e Democratização**: Ao simplificar o acesso a cálculos complexos através de uma interface amigável, o projeto amplia o espectro de usuários capacitados a realizar avaliações de risco, contribuindo para a disseminação da cultura de proteção radiológica e segurança.

## 1.5. Estrutura do Trabalho

Esta tese está organizada em cinco capítulos, além desta introdução e dos elementos pós-textuais:

*   **Capítulo 2 - Fundamentação Teórica**: Apresenta os conceitos de modelagem atmosférica, detalha os modelos BEIR V e VII e discute os princípios de engenharia de software aplicados.
*   **Capítulo 3 - Metodologia e Desenvolvimento**: Descreve a arquitetura do sistema Dose2Risk, os algoritmos de extração e cálculo, e as decisões de design de interface.
*   **Capítulo 4 - Resultados e Discussão**: Apresenta a validação técnica do sistema e três estudos de caso (RDD urbano, acidente nuclear e exposição ocupacional), discutindo os ganhos de eficiência e precisão.
*   **Capítulo 5 - Conclusões**: Sintetiza as contribuições do trabalho, limitações e propostas para trabalhos futuros.

---

**Referências do Capítulo:**

[1] ICRP. The 2007 Recommendations of the International Commission on Radiological Protection. ICRP Publication 103, 2007.
[2] Homann, S.G. HotSpot Health Physics Codes Version 3.0 User’s Guide. LLNL, 2013.
[3] National Research Council. Health Effects of Exposure to Low Levels of Ionizing Radiation: BEIR V. 1990.
[4] National Research Council. Health Risks from Exposure to Low Levels of Ionizing Radiation: BEIR VII Phase 2. 2006.
[5] IAEA. Criteria for Use in Preparedness and Response for a Nuclear or Radiological Emergency. GSG-2, 2011.
[6] Apostoaei, I.I. et al. Uncertainty and variability in cancer risk coefficients. Health Physics, 1999.
[8] Peng, R.D. Reproducible research in computational science. Science, 2011.
