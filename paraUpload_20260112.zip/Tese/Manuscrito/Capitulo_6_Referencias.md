# CAPÍTULO 6
# REFERÊNCIAS

[1] INTERNATIONAL COMMISSION ON RADIOLOGICAL PROTECTION (ICRP). The 2007 Recommendations of the International Commission on Radiological Protection. **ICRP Publication 103**, Ann. ICRP 37(2–4), 1–332, 2007. Disponível em: https://www.icrp.org/publication.asp?id=ICRP+Publication+103.

[2] HOMANN, S.G.; ALUZZI, F. **HotSpot Health Physics Codes Version 3.0 User’s Guide**. Lawrence Livermore National Laboratory, LLNL-SM-636474, 2013. Disponível em: https://narac.llnl.gov/sites/narac/files/2024-02/LLNL-SM-636474.pdf.

[3] NATIONAL RESEARCH COUNCIL (U.S.). **Health Effects of Exposure to Low Levels of Ionizing Radiation: BEIR V**. Washington, DC: The National Academies Press, 1990. DOI: 10.17226/1224.

[4] NATIONAL RESEARCH COUNCIL (U.S.). **Health Risks from Exposure to Low Levels of Ionizing Radiation: BEIR VII Phase 2**. Washington, DC: The National Academies Press, 2006. DOI: 10.17226/11340.

[5] INTERNATIONAL ATOMIC ENERGY AGENCY (IAEA). **Criteria for Use in Preparedness and Response for a Nuclear or Radiological Emergency**. IAEA Safety Standards Series No. GSG-2, Viena: IAEA, 2011.

[6] APOSTOAEI, I.I.; TRABALKA, J.R.; HOFFMAN, F.O. Uncertainty and variability in cancer risk coefficients for environmental exposure to radionuclides. **Health Physics**, 76(1): 16–27, 1999.

[7] INTERNATIONAL ATOMIC ENERGY AGENCY (IAEA). **Generic Procedures for Assessment and Response during a Radiological Emergency**. IAEA-TECDOC-1162, Viena: IAEA, 2000.

[8] PENG, R.D. Reproducible research in computational science. **Science**, 334(6060): 1226–1227, 2011. DOI: 10.1126/science.1213847.

[9] WILSON, G. et al. Good enough practices in scientific computing. **PLoS Comput. Biol.**, 13(6): e1005510, 2017.

[10] SANDVE, G.K. et al. Ten simple rules for reproducible computational research. **PLoS Comput. Biol.**, 9(10): e1003285, 2013.

[11] GRÜNING, B.A. et al. Jupyter and Galaxy: easing entry barriers into complex data analyses for biomedical researchers. **PLoS Comput. Biol.**, 13(5): e1005425, 2017.

[12] ARYA, S.P. **Air Pollution Meteorology and Dispersion**. Oxford: Oxford University Press, 1999.

[13] SEINFELD, J.H.; PANDIS, S.N. **Atmospheric Chemistry and Physics: From Air Pollution to Climate Change**. 3. ed. Hoboken: John Wiley & Sons, 2016.

[14] GAMMA, E. et al. **Design Patterns: Elements of Reusable Object-Oriented Software**. Boston: Addison-Wesley, 1994.

[15] BECK, K. **Test Driven Development: By Example**. Boston: Addison-Wesley, 2002.

[16] BRANDL, G. **Sphinx Documentation Generator**. 2007. Disponível em: https://www.sphinx-doc.org/.

[17] NORMAN, D.A. **The Design of Everyday Things**. Rev. ed. Nova Iorque: Basic Books, 2013.

[18] DUCKETT, J. **HTML and CSS: Design and Build Websites**. Indianapolis: John Wiley & Sons, 2011.

[19] WORLD WIDE WEB CONSORTIUM (W3C). **Web Content Accessibility Guidelines (WCAG) 2.1**. 2018. Disponível em: https://www.w3.org/TR/WCAG21/.

[20] MARTIN, R.C. **Clean Code: A Handbook of Agile Software Craftsmanship**. Upper Saddle River: Prentice Hall, 2008.

[21] FRIEDL, J.E.F. **Mastering Regular Expressions**. 3. ed. Sebastopol: O’Reilly Media, 2006.

[22] NIELSEN, J. **Usability Engineering**. Boston: Academic Press, 1993.

[23] KRUG, S. **Don’t Make Me Think: A Common Sense Approach to Web Usability**. 3. ed. Berkeley: New Riders, 2014.

[24] FREIRE, J. et al. Provenance for computational tasks: a survey. **Comput. Sci. Eng.**, 10(3): 11–21, 2008.

[25] GIL, Y. et al. Examining the challenges of scientific workflows. **Computer**, 40(12): 24–32, 2007.

[26] LIU, J. et al. A survey of data-intensive scientific workflow management. **J. Grid Comput.**, 13(4): 457–493, 2015.

[27] BATUT, B. et al. Community-driven data analysis training for biology. **Cell Syst.**, 6(6): 752–758.e1, 2018.

[28] SERRANO-SOLANO, B. et al. Fostering accessible online education using Galaxy as an e-learning platform. **PLoS Comput. Biol.**, 17(5): e1008923, 2021.

[29] WILKINSON, M.D. et al. The FAIR guiding principles for scientific data management and stewardship. **Sci. Data**, 3: 160018, 2016.

[30] U.S. DEPARTMENT OF ENERGY (DOE). **RESRAD RDD: Ferramenta DOE para avaliação de dispersão radiológica**. Disponível em: https://resrad.evs.anl.gov/codes/resrad-rdd/.
