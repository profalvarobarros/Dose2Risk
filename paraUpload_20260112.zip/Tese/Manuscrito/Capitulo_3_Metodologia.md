# CAPÍTULO 3
# METODOLOGIA E DESENVOLVIMENTO

Este capítulo descreve a metodologia de desenvolvimento do sistema Dose2Risk, detalhando sua arquitetura, os componentes de software implementados e os fluxos de dados estabelecidos para garantir a integração precisa entre as estimativas de dose do HotSpot e os modelos de risco BEIR.

## 3.1. Abordagem Metodológica

A pesquisa adotou uma abordagem de desenvolvimento de software científico baseada em **arquitetura orientada a dados** (*Data-Driven Architecture*). Diferentemente de implementações tradicionais onde coeficientes matemáticos são inseridos diretamente no código-fonte, o Dose2Risk externaliza toda a parametrização em arquivos de configuração estruturados (JSON). Isso confere ao sistema flexibilidade para atualizações científicas e transparência para auditoria.

O desenvolvimento seguiu o ciclo de vida iterativo, composto pelas fases de: (1) Análise de Requisitos e Modelagem Matemática; (2) Implementação Modular dos Componentes; e (3) Verificação e Validação Automatizada.

## 3.2. Arquitetura do Sistema

O sistema foi construído em linguagem Python 3, utilizando uma arquitetura modular que separa responsabilidades em camadas distintas de processamento.

### 3.2.1. Estrutura Modular
Os componentes principais do sistema são:

1.  **Módulo de Configuração e Parametrização**: Gerencia o arquivo `beir_hotspot_parameters.json`, que atua como o "cérebro" biológico do sistema.
2.  **Extrator (*Input Layer*)**: Utiliza o padrão **Factory Method** para instanciar parsers específicos conforme a versão do arquivo HotSpot.
3.  **Calculadora de Risco (*Risk Engine*)**: Implementa o padrão **Strategy**, permitindo a seleção dinâmica entre algoritmos de risco (BEIR V vs VI) em tempo de execução.
4.  **Interface Web (*Presentation Layer*)**: Desenvolvida com Flask, incorpora suporte à internacionalização (i18n) via **Flask-Babel**, permitindo alternância dinâmica entre Português, Inglês, Espanhol e Francês. A interface também adere às diretrizes de acessibilidade **WCAG 2.1** e oferece modo noturno (*Dark Mode*).

### 3.2.2. Fluxo de Dados e Arquivos de Saída

O pipeline gera quatro artefatos principais para garantir rastreabilidade completa, descritos na Tabela 3.1:

**Tabela 3.1** - Descrição dos arquivos gerados pelo pipeline Dose2Risk

| ID | Sufixo do Arquivo | Conteúdo | Formato |
| :---: | :--- | :--- | :---: |
| 1 | `_extracted.csv` | Dados brutos extraídos do HotSpot (TEDE e Doses) | CSV Long |
| 2 | `_transposed.csv` | Matriz pivotada (Órgãos x Distâncias) para cálculo | CSV Wide |
| 3 | `_risks.csv` | Resultados finais (ERR, LAR) com metadados | CSV |
| 4 | `_audit.log` | Log detalhado das equações e parâmetros usados | JSON |

## 3.3. Implementação dos Modelos Matemáticos

A implementação computacional dos modelos BEIR foi desenhada para suportar alta complexidade paramétrica sem perder desempenho.

### 3.3.1. Parametrização via JSON
O arquivo `config/beir_hotspot_parameters.json` permite a configuração granular. Por exemplo, para o modelo BEIR V de Tireoide, o sistema suporta coeficientes distintos por faixa etária (*age-dependent model*), aplicando automaticamente um fator de risco maior para crianças (< 18 anos) e menor para adultos, conforme definido na literatura.

### 3.3.2. Motor de Cálculo Híbrido
O algoritmo de cálculo opera célula a célula. Ao processar uma matriz de doses, o sistema pode aplicar o modelo BEIR VII para um órgão que recebeu baixa dose e, simultaneamente, aplicar o BEIR V para outro órgão no mesmo cenário que tenha recebido alta dose.

Adicionalmente, foi implementada uma **Trava de Segurança Metodológica** para doses extremas. O sistema interrompe o cálculo de risco estocástico (câncer futuro) se a dose absorvida exceder **4 Sv (4000 mSv)**, limiar onde predominam os efeitos determinísticos agudos (Síndrome Aguda da Radiação) e a probabilidade de sobrevivência imediata é reduzida, tornando o cálculo de risco vitalício (LAR) pouco representativo.

## 3.4. Interface e Usabilidade

A interface do usuário foi projetada seguindo princípios de usabilidade para minimizar a carga cognitiva e erros operacionais. O fluxo de trabalho é linear:
1.  **Upload**: O usuário carrega os arquivos de saída do HotSpot. O sistema valida imediatamente o formato.
2.  **Parametrização e Filtragem**: O usuário define parâmetros biológicos (idades) e aplica filtros de escopo (seleção de Sexo, Órgãos específicos e Modelos de Risco) para refinar a análise.
3.  **Processamento**: O sistema executa o pipeline, aplicando as regras de filtragem e segurança, e disponibiliza os arquivos para download.

## 3.5. Validação e Verificação

A metodologia de validação seguiu um protocolo rigoroso de garantia da qualidade:

1.  **Testes Unitários (PyTest)**: Desenvolvimento orientado a testes (TDD). Cada função matemática foi validada isoladamente contra valores de gabarito calculados em planilhas externas. A cobertura de código (*code coverage*) alvo foi superior a 85%.
2.  **Testes de Integração**: Verificação do fluxo de dados completo entre o Extrator e a Calculadora, garantindo que a transformação dos dados não introduz erros de arredondamento.
3.  **Testes de Sistema e Interface (Selenium)**: Simulação automatizada de interações do usuário (upload, clique em botões) para garantir que a interface web responda corretamente em diferentes navegadores.
4.  **Integração Contínua (CI)**: Pipeline configurado no **GitHub Actions** para executar a suíte de testes automaticamente a cada novo *commit*, impedindo a regressão do código.

---
**Referências do Capítulo:**
[Documentação Técnica do Sistema Dose2Risk v2.0]
