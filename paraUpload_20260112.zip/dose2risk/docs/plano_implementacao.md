# Plano de Ajustes e Implementação Gradual (MD-Compliance)

**Objetivo:** Elevar o nível de conformidade do software **DoseToRisk** com as normas do Ministério da Defesa (MD42, MD40, MD30), transformando-o em uma ferramenta robusta para Apoio de Saúde Operacional.

---

## Fase 1: Padronização Doutrinária (Curto Prazo - 1 Semana)
**Foco:** Terminologia e Documentação. Sem alterações no motor matemático.

*   [ ] **Revisão de Glossário (MD35-G-01):**
    *   Mapear termos do código (`TEDE`, `HotSpot`, `Risk`) para termos em português usados na doutrina (`Dose Efetiva Total`, `Área Quente`, `Risco Operacional`).
    *   Atualizar *docstrings* e *logs* para refletir essa terminologia.
*   [ ] **Metadados de Relatório:**
    *   Incluir no cabeçalho dos relatórios HTML/PDF a referência normativa: *"Relatório em conformidade com MD42-M-04 (Apoio de Saúde) e MD40-M-03 (Qualidade)"*.

## Fase 2: Expansão de Capacidade Operacional (Médio Prazo - 2 a 4 Semanas)
**Foco:** Incorporação de Efeitos Agudos (Deterministícos).

*   [ ] **Módulo de Casualties (Baixas Agudas):**
    *   Criar nova classe `AcuteRiskCalculator`.
    *   Implementar limiares de dose baseados em NATO AMedP-8(C) ou literatura médica de defesa.
    *   **Meta:** Calcular probabilidade de Vômito/Incapacitação Imediata para doses > 1 Gy.
*   [ ] **Integração no Pipeline:**
    *   O pipeline deve decidir: Se dose > Limite Agudo -> Acionar `AcuteRiskCalculator`. Se não -> Acionar `CalculadoraRisco` (BEIR VII).

## Fase 3: Garantia da Qualidade e Segurança (Longo Prazo - Contínuo)
**Foco:** MD40 e MD31 (Segurança da Informação e Ciclo de Vida).

*   [ ] **Assinatura Digital de Relatórios:**
    *   Implementar *checksum* final do relatório de saída para evitar adulteração pós-processamento.
*   [ ] **Teste de Validação Cruzada:**
    *   Criar bateria de testes unitários comparando saídas do software com tabelas oficiais do BEIR e manuais da defesa.

---

## Matriz de Risco do Plano
*   **Técnico:** Baixo risco. A arquitetura atual é modular e suporta novos modelos.
*   **Doutrinário:** Médio. Requer validação de especialistas para confirmar se os limiares de "Baixa Aguda" estão corretos para o teatro de operações brasileiro.
